package com.OnlinePizza.Pizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
