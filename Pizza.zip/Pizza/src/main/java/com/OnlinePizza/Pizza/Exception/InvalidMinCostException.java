package com.OnlinePizza.Pizza.Exception;

public class InvalidMinCostException extends Exception{
    public InvalidMinCostException(String message){
        super(message);
    }
}
