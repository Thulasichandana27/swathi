package com.OnlinePizza.Pizza.DTO;



import java.time.LocalDate;

public class PizzaOrder {
    private Long bookingOrderId;
    private String transactionMode;
    private int quantity;
    private String size;
    private double totalCost;


    private int pizzaId;





    private long couponId;


}
