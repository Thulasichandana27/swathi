package com.OnlinePizza.Pizza.Service;




import com.OnlinePizza.Pizza.DTO.PizzaDTO;
import com.OnlinePizza.Pizza.Entity.Pizza;
import com.OnlinePizza.Pizza.Entity.PizzaName;
import com.OnlinePizza.Pizza.Entity.PizzaSize;
import com.OnlinePizza.Pizza.Entity.PizzaType;
import com.OnlinePizza.Pizza.Exception.*;
import com.OnlinePizza.Pizza.Repository.IPizzaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class IPizzaServiceImpl implements IPizzaService {
    @Autowired
    private IPizzaRepository pizzaRepository;

    @Override
    public Pizza addPizza(PizzaDTO pizzaDTO) throws PizzaAlreadyExistsException {

        // Check for uniqueness
        List<Pizza> existingPizzas = pizzaRepository.findByPizzaName(pizzaDTO.getPizzaName());
        for (Pizza pizza : existingPizzas) {
            if (pizza.getPizzaSize() == pizzaDTO.getPizzaSize()) {
                throw new PizzaAlreadyExistsException("Pizza with name " + pizzaDTO.getPizzaName() + " and size " + pizzaDTO.getPizzaSize() + " already exists.");
            }
        }



        Pizza pizza = new Pizza();
        pizza.setPizzaType(pizzaDTO.getPizzaType());
        pizza.setPizzaSize(pizzaDTO.getPizzaSize());
        pizza.setPizzaName(pizzaDTO.getPizzaName());
        pizza.setPizzaCost(pizzaDTO.getPizzaCost());


        //pizza.setPizzaDescription(pizzaDTO.getPizzaDescription());

        /*pizza.calculateCost(); // Calculate the cost automatically
        pizza.updateMenu(); // Update the menu map*/
        return pizzaRepository.save(pizza);

    }


    @Override
    public Pizza updatePizza(int pizzaId, PizzaDTO pizzaDto) throws PizzaNotFoundException {
        Pizza pizza = pizzaRepository.findById(pizzaId).orElseThrow(() -> new PizzaNotFoundException("Pizza not found with id: " + pizzaId));
        pizza.setPizzaType(pizzaDto.getPizzaType());
        pizza.setPizzaSize(pizzaDto.getPizzaSize());
        pizza.setPizzaName(pizzaDto.getPizzaName());
        pizza.setPizzaCost(pizzaDto.getPizzaCost());
        /*pizza.setPizzaDescription(pizzaDto.getPizzaDescription());
        pizza.calculateCost(); // Calculate the cost automatically
        pizza.updateMenu(); // Update the menu map*/
        return pizzaRepository.save(pizza);
    }

    @Override
    public Pizza deletePizza(int pizzaId) throws PizzaIdNotFoundException {
        Pizza existingPizza = pizzaRepository.findById(pizzaId).orElse(null);

        if (existingPizza == null) {
            throw new PizzaIdNotFoundException("Pizza with ID " + pizzaId + " not found.");
        }

        pizzaRepository.delete(existingPizza);
        System.out.println("Pizza with ID " + pizzaId + " deleted successfully.");
        ;
        return existingPizza;
    }

    @Override
    public List<Pizza> viewPizzaList() throws PizzaListNotFoundException {
        List<Pizza> pizzaList = (List<Pizza>) pizzaRepository.findAll();
        if (pizzaList.isEmpty()) {
            throw new PizzaListNotFoundException("No pizzas available");
        }
        return pizzaList;


    }
    @Override
    public Pizza viewPizza(int pizzaId) throws PizzaIdNotFoundException {
        return pizzaRepository.findById(pizzaId)
                .orElseThrow(() -> new PizzaIdNotFoundException("Pizza not found with id " + pizzaId));
    }

    @Override
    public List<Pizza> viewPizzaList(Double minCost, Double maxCost) throws InvalidMinCostException, PizzaListNotFoundException {
        System.out.println("Entered viewPizzaList method with minCost: " + minCost + " and maxCost: " + maxCost);
        if (minCost == null || maxCost == null) {
            System.out.println("Validation failed: minCost or maxCost is null");
            throw new InvalidMinCostException("Cost values must not be null");
        }

        if (minCost < 0 || maxCost < 0) {
            System.out.println("Validation failed: minCost or maxCost is negative");
            throw new InvalidMinCostException("Cost values must be positive");
        }

        if (minCost > maxCost) {
            System.out.println("Validation failed: minCost is greater than maxCost");
            throw new InvalidMinCostException("Minimum cost cannot be greater than maximum cost");
        }
        List<Pizza> pizzas = pizzaRepository.findByPizzaCostBetween(minCost, maxCost);

        if (pizzas.isEmpty()) {
            System.out.println("No pizzas found in the specified range");
            throw new PizzaListNotFoundException("No pizzas found within the specified cost range");
        }

        System.out.println("Pizzas found: " + pizzas.size());
        return pizzas;
    }
    @Override
    public List<Pizza> viewPizzaList(PizzaType pizzaType) throws PizzaNotFoundException {
        // Fetch pizzas based on pizza type from the repository
        List<Pizza> pizzas = pizzaRepository.findByPizzaType(pizzaType);

        // If no pizzas are found, throw PizzaNotFoundException
        if (pizzas.isEmpty()) {
            throw new PizzaNotFoundException("No pizzas found for pizza type: " + pizzaType);
        }

        return pizzas;
    }
    @Override
    public List<Pizza> viewPizzaBySizeAndName(PizzaName pizzaName, PizzaSize pizzaSize) throws PizzaNotFoundException {
        // Retrieve pizzas from the repository
        List<Pizza> pizzas = pizzaRepository.findByPizzaNameAndPizzaSize(pizzaName, pizzaSize);

        // Check if pizzas are found, else throw exception
        if (pizzas.isEmpty()) {
            throw new PizzaNotFoundException("No pizzas found for the given name and size.");
        }

        return pizzas;
    }
    
    @Override
    public Pizza getPizza(Integer pizzaId) {
    	 Pizza pizza = pizzaRepository.findByPizzaId(pizzaId);
    	    if (pizza == null) {
    	        throw new RuntimeException("Pizza not found with ID: " + pizzaId);
    	    }
    	    return pizza;
    }
    
   
    
    @Override 
    public Double getPizzaCost(Integer pizzaId) {
    	Double cost =  pizzaRepository.findByPizzaId(pizzaId).getPizzaCost();
    	if(cost == null) {
    		throw new RuntimeException ("cost not found");
    	}
    	
    	return cost;
    }
    
//    public Double getPizzaCost(int pizzaId) {
//        Optional<Pizza> pizza = pizzaRepository.findById(pizzaId);
//        return pizza.map(Pizza::getPizzaCost).orElseThrow(() -> new RuntimeException("Pizza not found with ID: " + pizzaId));
//    }


	
    
    
}



