package com.OnlinePizza.Pizza.Exception;

public class PizzaAlreadyExistsException extends Exception{
    public PizzaAlreadyExistsException(String message){
        super(message);
    }
}
