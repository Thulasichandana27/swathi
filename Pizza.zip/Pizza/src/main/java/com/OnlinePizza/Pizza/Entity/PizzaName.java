package com.OnlinePizza.Pizza.Entity;



import java.util.Arrays;
import java.util.List;

public enum PizzaName {
    //MARGHERITA("Margherita","Cheese,Tomato,Basil");
    //MARGHERITA("Margherita", "Classic vegetarian pizza with tomatoes and cheese."),
    MARGHERITA("Margherita", "Tomatoes, Mozzarella, Basil"),
    PEPPERONI("Pepperoni", "Non-vegetarian pizza with pepperoni and cheese."),
    VEGGIE_DELIGHT("Veggie Delight", "A delightful mix of vegetables and cheese."),
    BBQ_CHICKEN("BBQ Chicken", "Non-vegetarian pizza with BBQ chicken and cheese."),
    HAWAIIAN("Hawaiian", "Tropical pizza topped with ham, pineapple, and cheese."),
    MARGHERITA_EXTRA("Margherita Extra", "Classic Margherita with added mozzarella and fresh basil."),
    PESTO_CHICKEN("Pesto Chicken", "Chicken topped with creamy pesto sauce, mozzarella, and sundried tomatoes."),
    SPICY_SALSICCIA("Spicy Salsiccia", "Italian sausage with a spicy kick, mozzarella, and a drizzle of chili oil."),
    MUSHROOM_FIESTA("Mushroom Fiesta", "A variety of fresh mushrooms, mozzarella, and garlic, perfect for mushroom lovers."),
    MEAT_FEAST("Meat Feast", "A carnivore's delight with pepperoni, sausage, bacon, and ham, all on a cheesy base."),
    BUFFALO_CHICKEN("Buffalo Chicken", "Spicy buffalo sauce, grilled chicken, and mozzarella for a zesty twist."),
    VEGGIE_SUPREME("Veggie Supreme", "A hearty mix of bell peppers, onions, olives, and mushrooms with cheese."),
    SEAFOOD_DELIGHT("Seafood Delight", "A blend of shrimp, calamari, and anchovies topped with mozzarella."),
    CHEESY_GARLIC_BREAD("Cheesy Garlic Bread", "Garlic butter, mozzarella, and parmesan cheese on a crispy crust."),
    SUPREME_PIZZA("Supreme Pizza", "A combination of pepperoni, sausage, olives, onions, and bell peppers."),
    TROPICAL_PARADISE("Tropical Paradise", "Pineapple, ham, and coconut with a hint of lime zest for a sweet and savory taste."),
    BBQ_RANCH("BBQ Ranch", "BBQ sauce, grilled chicken, and ranch dressing with mozzarella cheese."),
    ITALIAN_BLT("ITALIAN_BLT","Classic pepperoni, fresh basil leaves, and mozzarella cheese on a tangy tomato sauce base.");
    private String pizzaName;
    private String pizzaDescription;


    PizzaName(String pizzaName, String pizzaDescription) {
        this.pizzaName = pizzaName;
        this.pizzaDescription = pizzaDescription;
    }

    public String getPizzaName() {
        return pizzaName;
    }

    public String getPizzaDescription() {
        return pizzaDescription;
    }

    public void setPizzaName(String pizzaName) {
        this.pizzaName = pizzaName;
    }

    public void setPizzaDescription(String pizzaDescription) {
        this.pizzaDescription = pizzaDescription;
    }


}




