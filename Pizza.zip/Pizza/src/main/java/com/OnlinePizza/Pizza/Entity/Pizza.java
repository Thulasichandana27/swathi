package com.OnlinePizza.Pizza.Entity;





import jakarta.persistence.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Entity
@Table(name="pizzas_table")
public class Pizza {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int pizzaId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PizzaType pizzaType;


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PizzaName pizzaName;


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PizzaSize pizzaSize;

    @Column(nullable = false)
    private Double pizzaCost;

    // private String pizzaDescription;


    public Pizza() {
    }

    public Pizza(int pizzaId, PizzaType pizzaType, PizzaName pizzaName, PizzaSize pizzaSize, Double pizzaCost) {
        this.pizzaId = pizzaId;
        this.pizzaType = pizzaType;
        this.pizzaName = pizzaName;
        this.pizzaSize = pizzaSize;
        this.pizzaCost = pizzaCost;


    }

    public int getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(int pizzaId) {
        this.pizzaId = pizzaId;
    }

    public PizzaType getPizzaType() {
        return pizzaType;
    }

    public void setPizzaType(PizzaType pizzaType) {
        this.pizzaType = pizzaType;
    }

    public PizzaName getPizzaName() {
        return pizzaName;
    }

    public void setPizzaName(PizzaName pizzaName) {
        this.pizzaName = pizzaName;
    }

    public PizzaSize getPizzaSize() {
        return pizzaSize;
    }

    public void setPizzaSize(PizzaSize pizzaSize) {
        this.pizzaSize = pizzaSize;
    }

    public Double getPizzaCost() {
        return pizzaCost;
    }

    public void setPizzaCost(Double pizzaCost) {
        this.pizzaCost = pizzaCost;
    }


    public String getPizzaDescription() {
        if (pizzaName != null) {
            return pizzaName.getPizzaDescription();  // Fetch description from the enum
        }
        return null;
    }
}

































/*
    @ElementCollection
    private Set<PizzaName> menu = new HashSet<>();

    @PrePersist
    @PreUpdate
    public void updateMenu() {
        menu.add(pizzaName);
    }
    public void calculateCost() {
        double baseCost = 0;
        switch (pizzaSize) {
            case SMALL:
                baseCost = 120.0;
                break;
            case MEDIUM:
                baseCost = 200.0;
                break;
            case LARGE:
                baseCost = 250.0;
                break;
        }
        if (pizzaType == PizzaType.NON_VEG) {
            baseCost += 45.0;
        }
        this.pizzaCost = baseCost;
    }
*/


