package com.OnlinePizza.Pizza.DTO;





import com.OnlinePizza.Pizza.Entity.PizzaName;
import com.OnlinePizza.Pizza.Entity.PizzaSize;
import com.OnlinePizza.Pizza.Entity.PizzaType;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;


public class PizzaDTO {

	
    private int pizzaId;

    @NotNull(message = "{pizzaType.notnull}")
    private PizzaType pizzaType;

    @NotNull(message = "{pizzaName.notnull}")
    private PizzaName pizzaName;

    @NotNull(message = "{pizzaSize.notnull}")
    private PizzaSize pizzaSize;

    @NotNull(message = "{pizzaCost.notnull}")
    @Min(value = 90, message = "{pizzaCost.min}")
    @Max(value = 450, message = "{pizzaCost.max}")
    @Positive(message = "{pizzaCost.positive}")
    private Double pizzaCost;

    // private String pizzaDescription;


    
    
    public PizzaDTO() {
    }

    public PizzaDTO(int pizzaId, PizzaType pizzaType, PizzaName pizzaName, PizzaSize pizzaSize, Double pizzaCost) {
        this.pizzaId = pizzaId;
        this.pizzaType = pizzaType;
        this.pizzaName = pizzaName;
        this.pizzaSize = pizzaSize;
        this.pizzaCost = pizzaCost;
        //this.pizzaDescription=pizzaDescription;
    }

    /*public String getPizzaDescription() {
        return pizzaDescription;
    }

    public void setPizzaDescription(String pizzaDescription) {
        this.pizzaDescription = pizzaDescription;
    }*/

    public int getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(int pizzaId) {
        this.pizzaId = pizzaId;
    }

    public PizzaType getPizzaType() {
        return pizzaType;
    }

    public void setPizzaType(PizzaType pizzaType) {
        this.pizzaType = pizzaType;
    }

    public PizzaName getPizzaName() {
        return pizzaName;
    }

    public void setPizzaName(PizzaName pizzaName) {
        this.pizzaName = pizzaName;
    }

    public PizzaSize getPizzaSize() {
        return pizzaSize;
    }

    public void setPizzaSize(PizzaSize pizzaSize) {
        this.pizzaSize = pizzaSize;
    }

    public Double getPizzaCost() {
        return pizzaCost;
    }

    public void setPizzaCost(Double pizzaCost) {
        this.pizzaCost = pizzaCost;
    }
}
