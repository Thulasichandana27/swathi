package com.OnlinePizza.Pizza.Exception;

public class PizzaListNotFoundException extends Exception{
    public PizzaListNotFoundException(String message){
        super(message);
    }
}

