package com.OnlinePizza.Pizza.Repository;



import com.OnlinePizza.Pizza.Entity.Pizza;
import com.OnlinePizza.Pizza.Entity.PizzaName;
import com.OnlinePizza.Pizza.Entity.PizzaSize;
import com.OnlinePizza.Pizza.Entity.PizzaType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IPizzaRepository extends CrudRepository<Pizza, Integer> {
    List<Pizza> findByPizzaName(PizzaName pizzaName);

    List<Pizza> findByPizzaCostBetween(Double minCost, Double maxCost);

    List<Pizza> findByPizzaType(PizzaType pizzaType);

    List<Pizza> findByPizzaNameAndPizzaSize(PizzaName pizzaName, PizzaSize pizzaSize);
    
    Pizza findByPizzaId (Integer pizzaId);

}
