package com.OnlinePizza.Pizza.Exception;






import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();

        // Iterate through each validation error and extract the message
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }



    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<String> handleInvalidEnumArgument(MethodArgumentTypeMismatchException ex) {
        // Get the invalid value that caused the exception
        String invalidValue = ex.getValue().toString();

        // Get the name of the parameter that caused the mismatch
        String parameterName = ex.getName();

        // Generate appropriate error message based on the parameter name
        String errorMessage = "";

        if (parameterName.equalsIgnoreCase("pizzaType")) {
            errorMessage = "Invalid PizzaType value: '" + invalidValue + "'. Accepted values are: VEG, NON_VEG.";
        } else if (parameterName.equalsIgnoreCase("pizzaName")) {
            errorMessage = "Invalid PizzaName value: '" + invalidValue + "'. Accepted values are: MARGHERITA, PEPPERONI, VEGGIE.";
        } else if (parameterName.equalsIgnoreCase("pizzaSize")) {
            errorMessage = "Invalid PizzaSize value: '" + invalidValue + "'. Accepted values are: SMALL, MEDIUM, LARGE.";
        } else {
            errorMessage = "Invalid input: '" + invalidValue + "'. Please provide a valid value.";
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Map<String, String>> handleConstraintViolationException(ConstraintViolationException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getConstraintViolations().forEach(violation -> {
            errors.put(violation.getPropertyPath().toString(), violation.getMessage());
        });

        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST); // 400 Bad Request
    }

    @ExceptionHandler(PizzaIdNotFoundException.class)
    public ResponseEntity<String> handlePizzaIdNotFoundException(PizzaIdNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(PizzaAlreadyExistsException.class)
    public ResponseEntity<String> handlePizzaListNotFoundException(PizzaAlreadyExistsException ex) {
        // Return custom error message with 404 NOT FOUND
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(org.springframework.web.client.HttpClientErrorException.BadRequest.class)
    public ResponseEntity<String> handleBadRequestException(org.springframework.web.client.HttpClientErrorException.BadRequest ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PizzaNotFoundException.class)
    public ResponseEntity<String> handlePizzaListNotFoundException(PizzaNotFoundException ex) {
        // Return custom error message with 404 NOT FOUND
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(PizzaListNotFoundException.class)
    public ResponseEntity<String> handlePizzaListNotFoundException(PizzaListNotFoundException ex) {
        // Return custom error message with 404 NOT FOUND
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(InvalidMinCostException.class)
    public ResponseEntity<String> handleResourceNotFoundException(InvalidMinCostException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

}


