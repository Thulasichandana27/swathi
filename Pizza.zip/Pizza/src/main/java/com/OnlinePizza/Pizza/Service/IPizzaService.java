package com.OnlinePizza.Pizza.Service;





import com.OnlinePizza.Pizza.DTO.PizzaDTO;
import com.OnlinePizza.Pizza.Entity.Pizza;
import com.OnlinePizza.Pizza.Entity.PizzaName;
import com.OnlinePizza.Pizza.Entity.PizzaSize;
import com.OnlinePizza.Pizza.Entity.PizzaType;
import com.OnlinePizza.Pizza.Exception.*;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public interface IPizzaService {
    Pizza addPizza(PizzaDTO pizzaDTO) throws PizzaAlreadyExistsException;
    Pizza updatePizza(int pizzaId, PizzaDTO pizzaDto) throws PizzaNotFoundException;
    Pizza deletePizza(int pizzaId) throws PizzaIdNotFoundException;
    List<Pizza> viewPizzaList() throws PizzaListNotFoundException;
    Pizza viewPizza(int pizzaId) throws PizzaIdNotFoundException;
    List<Pizza> viewPizzaList(Double minCost, Double maxCost) throws InvalidMinCostException,PizzaListNotFoundException;
    List<Pizza> viewPizzaList(PizzaType pizzaType) throws PizzaNotFoundException;
    List<Pizza> viewPizzaBySizeAndName(PizzaName pizzaName, PizzaSize pizzaSize) throws PizzaNotFoundException;
    Pizza getPizza(Integer pizzaId);
    Double getPizzaCost(Integer pizzaId);

    
    
    
    
    
    
}
