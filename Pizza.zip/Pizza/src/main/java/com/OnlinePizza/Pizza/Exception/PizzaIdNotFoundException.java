package com.OnlinePizza.Pizza.Exception;

public class PizzaIdNotFoundException extends Exception{
    public PizzaIdNotFoundException(String message){
        super(message);
    }
}
