package com.OnlinePizza.Pizza.Controller;




import com.OnlinePizza.Pizza.DTO.PizzaDTO;
import com.OnlinePizza.Pizza.Entity.Pizza;
import com.OnlinePizza.Pizza.Entity.PizzaName;
import com.OnlinePizza.Pizza.Entity.PizzaSize;
import com.OnlinePizza.Pizza.Entity.PizzaType;
import com.OnlinePizza.Pizza.Exception.*;
import com.OnlinePizza.Pizza.Service.IPizzaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.List;
//import java.util.Map;



@RestController
@RequestMapping("/pizzas")
@Validated
public class PizzaController {

    @Autowired
    private IPizzaService pizzaService;

    @PostMapping("/add")
    public ResponseEntity<Pizza> addPizza(@Valid @RequestBody PizzaDTO pizzaDTO) throws PizzaAlreadyExistsException {
        Pizza pizza = pizzaService.addPizza(pizzaDTO);
        return new ResponseEntity<>(pizza, HttpStatus.CREATED);
    }
    
    
   
    
    @GetMapping("/getPizzaId/{id}")
    public ResponseEntity<Pizza> getPizzaId(@PathVariable("id") Integer pizzaId) {
        Pizza pizza = pizzaService.getPizza(pizzaId); // Assuming pizzaService has a getPizza method
        return new ResponseEntity<>(pizza, HttpStatus.OK);
    }
    
    @GetMapping ("/getPizzaCost/{id}")
    public ResponseEntity<Double> getPizzaCost(@PathVariable("id") Integer pizzaId){
    	Double price = pizzaService.getPizzaCost(pizzaId);
    	return new ResponseEntity<>(price, HttpStatus.OK);
    }

    
    
    
//    @Override
//    public Pizza getPizza(Integer pizzaId) {
//    	 Pizza pizza = pizzaRepository.findByPizzaId(pizzaId);
//    	    if (pizza == null) {
//    	        throw new RuntimeException("Pizza not found with ID: " + pizzaId);
//    	    }
//    	    return pizza;
//    }
    
   
//    
//    @Override 
//    public Double getPizzaCost(Integer pizzaId) {
//    	Double cost =  pizzaRepository.findByPizzaId(pizzaId).getPizzaCost();
//    	if(cost == null) {
//    		throw new RuntimeException ("cost not found");
//    	}
//    	
//    	return cost;
//    }
    
    
    

    @PutMapping("/{pizzaId}")
    public ResponseEntity<Pizza> updatePizza(@PathVariable int pizzaId, @Valid @RequestBody PizzaDTO pizzaDTO) throws PizzaNotFoundException {
        Pizza pizza = pizzaService.updatePizza(pizzaId, pizzaDTO);
        return new ResponseEntity<>(pizza, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{pizzaId}")
    public ResponseEntity<String> deletePizza(@PathVariable int pizzaId) {
        try {
            pizzaService.deletePizza(pizzaId);  // This should call the deletePizza method
            return ResponseEntity.ok("Pizza deleted successfully.");
        } catch (PizzaIdNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/viewAll")
    public ResponseEntity<List<Pizza>> viewPizzaList() throws PizzaListNotFoundException {
        List<Pizza> pizzaList = pizzaService.viewPizzaList();
        return new ResponseEntity<>(pizzaList, HttpStatus.OK);
    }

    @GetMapping("/view/{pizzaId}")
    public ResponseEntity<Pizza> viewPizza(@PathVariable("pizzaId") int pizzaId) throws PizzaIdNotFoundException {
        Pizza pizza = pizzaService.viewPizza(pizzaId);
        return new ResponseEntity<>(pizza, HttpStatus.OK);


    }


    @GetMapping("/viewByCost")
    public ResponseEntity<?> viewPizzaList(@RequestParam Double minCost, @RequestParam Double maxCost) {
        System.out.println("Request received with minCost: " + minCost + " and maxCost: " + maxCost);

        try {
            List<Pizza> pizzas = pizzaService.viewPizzaList(minCost, maxCost);
            System.out.println("Returning pizza list of size: " + pizzas.size());
            return new ResponseEntity<>(pizzas, HttpStatus.OK);
        } catch (InvalidMinCostException ex) {
            System.out.println("InvalidMinCostException: " + ex.getMessage());
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (PizzaListNotFoundException ex) {
            System.out.println("PizzaListNotFoundException: " + ex.getMessage());
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            System.out.println("Exception occurred: " + ex.getMessage());
            return new ResponseEntity<>("An unexpected error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/viewByType")
    public ResponseEntity<?> viewPizzaList(@RequestParam("pizzaType") PizzaType pizzaType) throws PizzaNotFoundException{
        try {
            // Fetch pizzas by pizza type from the service layer
            List<Pizza> pizzas = pizzaService.viewPizzaList(pizzaType);

            // If no pizzas are found, return a message
            if (pizzas.isEmpty()) {
                return ResponseEntity.status(404).body("No pizzas found for pizza type: " + pizzaType);
            }

            return ResponseEntity.ok(pizzas);
        } catch (IllegalArgumentException e) {
            // Handle invalid PizzaType input (this case should ideally never happen if PizzaType is an enum)
            return ResponseEntity.badRequest().body("Invalid pizza type provided. Accepted values are: VEG, NON_VEG, etc.");
        } catch (PizzaNotFoundException e) {
            // Handle no pizzas found for the given type
            return ResponseEntity.status(404).body("No pizzas found for the given pizza type.");
        }
    }


    @GetMapping("/viewBySizeAndName")
    public ResponseEntity<?> viewPizzaBySizeAndName(
            @RequestParam("pizzaName") PizzaName pizzaName,
            @RequestParam("pizzaSize") PizzaSize pizzaSize) throws PizzaNotFoundException {

        try {
            // Get pizzas by pizzaName and pizzaSize
            List<Pizza> pizzas = pizzaService.viewPizzaBySizeAndName(pizzaName, pizzaSize);

            // Return pizzas if found
            return ResponseEntity.ok(pizzas);

        } catch (PizzaNotFoundException e) {
            // Handle when no pizzas are found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (MethodArgumentTypeMismatchException e) {
            // Handle invalid enum values in the request
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid input: " + e.getMessage() + ". Accepted values are: " + PizzaName.values() + " and " + PizzaSize.values());
        } catch (Exception e) {
            // Handle any other unexpected exceptions
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred: " + e.getMessage());
        }
    }
    





}







