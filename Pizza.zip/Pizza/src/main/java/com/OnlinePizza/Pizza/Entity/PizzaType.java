package com.OnlinePizza.Pizza.Entity;

public enum PizzaType {
    VEG,NON_VEG;
}
