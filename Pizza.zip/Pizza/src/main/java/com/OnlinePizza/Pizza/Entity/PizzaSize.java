package com.OnlinePizza.Pizza.Entity;

public enum PizzaSize {
    SMALL,
    MEDIUM,
    LARGE;
}