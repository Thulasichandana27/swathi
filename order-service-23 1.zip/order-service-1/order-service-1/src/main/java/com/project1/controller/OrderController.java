package com.project1.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.FieldError;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderAlreadyExistsException;
import com.project1.exception.OrderNotFoundException;
import com.project1.service.IOrderService;
import jakarta.validation.Valid;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private IOrderService orderService;

    // Add Order with validation
    @PostMapping("/add")
    public ResponseEntity<Object> addOrder(@Valid @RequestBody OrderDTO orderDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // Collect validation errors
            Map<String, String> errors = new HashMap<>();
            bindingResult.getAllErrors().forEach((error) -> {
                String fieldName = ((FieldError) error).getField();
                String errorMessage = error.getDefaultMessage();
                errors.put(fieldName, errorMessage);
            });
            // Return 400 with validation errors
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }

        try {
            // Add order via service
            OrderDTO createdOrder = orderService.addOrder(orderDTO);
            return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
        } catch (OrderAlreadyExistsException e) {
            // Handle custom exception
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Update Order with validation
    @PutMapping("/{orderId}")
    public ResponseEntity<Object> updateOrder(@PathVariable Long orderId, @Valid @RequestBody OrderDTO orderDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // Collect validation errors
            Map<String, String> errors = new HashMap<>();
            bindingResult.getAllErrors().forEach((error) -> {
                String fieldName = ((FieldError) error).getField();
                String errorMessage = error.getDefaultMessage();
                errors.put(fieldName, errorMessage);
            });
            // Return 400 with validation errors
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }

        try {
            // Update order via service
            OrderDTO updatedOrder = orderService.updateOrder(orderId, orderDTO);
            return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
        } catch (OrderNotFoundException e) {
            // Handle custom exception
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Get Order by ID
    @GetMapping("/{orderId}")
    public ResponseEntity<Object> getOrder(@PathVariable Long orderId) {
        try {
            // Get order via service
            OrderDTO order = orderService.viewOrder(orderId);
            return new ResponseEntity<>(order, HttpStatus.OK);
        } catch (OrderNotFoundException e) {
            // Handle custom exception
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Get Orders by User ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<OrderDTO>> getOrdersByUserId(@PathVariable int userId) {
        List<OrderDTO> orders = orderService.viewOrdersByUserId(userId);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // Get Orders by Location
    @GetMapping("/location/{location}")
    public ResponseEntity<List<OrderDTO>> getOrdersByLocation(@PathVariable String location) {
        List<OrderDTO> orders = orderService.viewOrdersByLocation(location);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // Get Orders by Date
    @GetMapping("/date/{date}")
    public ResponseEntity<List<OrderDTO>> getOrdersByDate(@PathVariable String date) {
        LocalDate orderDate = LocalDate.parse(date);
        List<OrderDTO> orders = orderService.viewOrdersByDate(orderDate);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }
    @DeleteMapping("/remove_product/{id}")
    public ResponseEntity<Order> removeOrder(@PathVariable Long id) throws OrderNotFoundException {
        Order removedOrder = orderService.removeOrder(id);
        return new ResponseEntity<>(removedOrder, HttpStatus.OK);
    }
   
}
