package com.project1.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project1.entity.OrderLine;

@Repository
public interface IOrderLineRepository extends JpaRepository<OrderLine, Long>{
	List<OrderLine> findByProductId(Long productId);
    List<OrderLine> findByQuantity(Integer quantity);
	List<OrderLine> findByOrderLineId(Long orderId);
	
}
