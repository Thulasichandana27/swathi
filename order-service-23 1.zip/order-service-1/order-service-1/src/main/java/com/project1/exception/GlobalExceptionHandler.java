package com.project1.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Handle custom OrderNotFoundException
    @ExceptionHandler(OrderNotFoundException.class)
    public ResponseEntity<?> handleOrderNotFoundException(OrderNotFoundException ex, WebRequest request) {
        // Return a 404 (Not Found) with the error message
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    // Handle custom OrderAlreadyExistsException
    @ExceptionHandler(OrderAlreadyExistsException.class)
    public ResponseEntity<?> handleOrderAlreadyExistsException(OrderAlreadyExistsException ex, WebRequest request) {
        // Return a 409 (Conflict) with the error message
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
    }

    // Handle validation exceptions (MethodArgumentNotValidException)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex, WebRequest request) {
        // Collect the field validation errors into a map
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();  // Get the field name that failed validation
            String errorMessage = error.getDefaultMessage();    // Get the validation error message
            errors.put(fieldName, errorMessage);
        });
        // Return a 400 (Bad Request) with the validation errors
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    // Handle any other general exceptions (fallback)
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleGlobalException(Exception ex, WebRequest request) {
        // Return a 500 (Internal Server Error) with a general error message
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(OrderLineNotFoundException.class)
    public ResponseEntity<?> handleOrderLineNotFoundException(OrderLineNotFoundException ex, WebRequest request) {
        // Return a 404 (Not Found) with the error message
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

}
