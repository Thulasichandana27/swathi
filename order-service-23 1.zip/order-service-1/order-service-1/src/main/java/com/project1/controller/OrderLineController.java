package com.project1.controller;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project1.dto.OrderLineDTO;
import com.project1.entity.OrderLine;
import com.project1.exception.OrderLineNotFoundException;
import com.project1.service.IOrderLineService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/orderlines")
public class OrderLineController {
	  @Autowired
	    private IOrderLineService orderLineService;

	    // Add OrderLine with validation
	    @PostMapping("/add")
	    public ResponseEntity<Object> addOrderLine(@Valid @RequestBody OrderLineDTO orderLineDTO, BindingResult bindingResult) {
	        if (bindingResult.hasErrors()) {
	            // Collect validation errors
	            Map<String, String> errors = new HashMap<>();
	            bindingResult.getAllErrors().forEach((error) -> {
	                String fieldName = ((FieldError) error).getField();
	                String errorMessage = error.getDefaultMessage();
	                errors.put(fieldName, errorMessage);
	            });
	            // Return 400 with validation errors
	            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	        }
	        if (orderLineDTO.getOrderLineId() == null) {
	            return new ResponseEntity<>("Order ID cannot be null", HttpStatus.BAD_REQUEST);
	        }

	        OrderLineDTO createdOrderLine = orderLineService.addOrderLine(orderLineDTO);
	        return new ResponseEntity<>(createdOrderLine, HttpStatus.CREATED);
	    }

	    // Get OrderLine by ID
	    @GetMapping("/{orderLineId}")
	    public ResponseEntity<Object> getOrderLine(@PathVariable Long orderLineId) {
	        try {
	            OrderLineDTO orderLine = orderLineService.viewOrderLine(orderLineId);
	            return new ResponseEntity<>(orderLine, HttpStatus.OK);
	        } catch (OrderLineNotFoundException e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	        }
	    }

	    // Get OrderLines by Product ID
	    @GetMapping("/product/{productId}")
	    public ResponseEntity<List<OrderLineDTO>> getOrderLinesByProductId(@PathVariable Long productId) {
	        List<OrderLineDTO> orderLines = orderLineService.viewOrderLinesByProductId(productId);
	        return new ResponseEntity<>(orderLines, HttpStatus.OK);
	    }

	    // Get OrderLines by Order ID
	    @GetMapping("/order/{orderId}")
	    public ResponseEntity<List<OrderLineDTO>> getOrderLinesByOrderId(@PathVariable Long orderId) {
	        List<OrderLineDTO> orderLines = orderLineService.viewOrderLinesByOrderId(orderId);
	        return new ResponseEntity<>(orderLines, HttpStatus.OK);
	    }

	    // Delete OrderLine by ID
	    @DeleteMapping("/remove/{orderLineId}")
	    public ResponseEntity<OrderLine> removeOrderLine(@PathVariable Long orderLineId) throws OrderLineNotFoundException {
	        OrderLine removedOrderLine = orderLineService.removeOrderLine(orderLineId);
	        return new ResponseEntity<>(removedOrderLine, HttpStatus.OK);
	    }

}
