package com.onlinepizza.coupon.dto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

import com.onlinepizza.coupon.Entity.CouponCode;
import com.onlinepizza.coupon.Entity.CouponType;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CouponDTO {

    private int id;

    @NotNull(message = "{code.notnull}")
    @Pattern(regexp = "^(CODE|COUPON)([1-9][0-9]{0,4})$", message = "{code.pattern}")
    private String code;

    private CouponType type;



    @NotNull(message="{bookingOrderId.notnull}")
    @Column(name = "bookingOrderId", nullable = false)
    private Integer bookingOrderId;
    private LocalDate expiryDate;  // Changed from Date to LocalDate for better date handling

    private Double totalCost;
    
    private Double finalTotalCost;

    // Method to handle the initialization after deserialization
    public void initializeFields() {
        

        // Recalculate totalCost, expiryDate, and set coupon type when the coupon is created
        this.finalTotalCost = calculateTotalCost(this.totalCost);  // Adjusted: Removed the type as it's determined by cost
        this.expiryDate = calculateExpiryDate();
        this.type = determineCouponType(this.totalCost);  // Set the type based on cost
        
        if (!CouponCode.isValidCode(this.code)) {
            throw new IllegalArgumentException("Invalid coupon code format.");
        }
    }

    // Calculate expiry date by adding 30 days to the current date
    private LocalDate calculateExpiryDate() {
        return LocalDate.now().plusDays(30);  // Adds 30 days to the current date
    }

    // Calculate total cost based on cost ranges and their respective discounts
    private double calculateTotalCost(double totalCost) {
        if (totalCost <= 300) {
            return totalCost;  // No discount, total cost is the same as the cost
        } else if (totalCost <= 600) {
            return totalCost * 0.95;  // 5% discount
        } else if (totalCost <= 1000) {
            return totalCost * 0.88;  // 12% discount
        } else if (totalCost <= 1500) {
            return totalCost * 0.75;  // 25% discount
        } else {
            return totalCost - 700;  // Fixed discount of 700 for cost > 1500
        }
    }

    // Determine the coupon type based on cost
    private CouponType determineCouponType(double totalCost) {
        if (totalCost <= 1500) {
            return CouponType.PERCENTAGE_DISCOUNT_TYPE;  // Set as PERCENTAGE_DISCOUNT_TYPE for cost <= 1500
        } else {
            return CouponType.FIXED_AMOUNT_TYPE;  // Set as FIXED_AMOUNT_TYPE for cost > 1500
        }
    }
}




//done



