package com.onlinepizza.coupon.Exception;

public class InvalidCostRangeException extends RuntimeException {
    public InvalidCostRangeException(String message) {
        super(message);
    }
}