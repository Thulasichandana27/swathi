package com.onlinepizza.coupon.Entity;

public enum CouponType {
    PERCENTAGE_DISCOUNT_TYPE, FIXED_AMOUNT_TYPE
}
