package com.onlinepizza.coupon.Exception;

import org.springframework.web.bind.annotation.ResponseStatus;


public class InvalidCouponOperationException extends RuntimeException {
    public InvalidCouponOperationException(String message) {
        super(message);
    }
}
