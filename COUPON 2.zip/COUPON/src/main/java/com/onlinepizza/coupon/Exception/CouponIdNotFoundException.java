package com.onlinepizza.coupon.Exception;

import org.springframework.web.bind.annotation.ResponseStatus;


public class CouponIdNotFoundException extends RuntimeException {
    public CouponIdNotFoundException(String message) {
        super(message);
    }
}

