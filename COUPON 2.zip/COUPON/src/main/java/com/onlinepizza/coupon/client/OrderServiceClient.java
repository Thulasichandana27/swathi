package com.onlinepizza.coupon.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.onlinepizza.coupon.dto.PizzaOrderDTO;

@FeignClient(value="OrderingModule",url="http://localhost:5002/pizza-orders")
@Component
public interface OrderServiceClient {

	@GetMapping("/{bookingOrderId}")
    public ResponseEntity<PizzaOrderDTO> viewPizzaOrder(@PathVariable int bookingOrderId);
       
}
