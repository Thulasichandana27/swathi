package com.onlinepizza.coupon.repository;

import com.onlinepizza.coupon.Entity.Coupon;
import com.onlinepizza.coupon.Entity.CouponCode;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CouponRepository extends JpaRepository<Coupon, Integer> {

     Coupon findByCode(String Couponcode);
     //boolean existsByCode(CouponCode code);
     boolean existsByCode(String code);
	
}

//done//done


