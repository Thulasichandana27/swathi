package com.onlinepizza.coupon.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.onlinepizza.coupon.Entity.Coupon;
import com.onlinepizza.coupon.Entity.CouponCode;
import com.onlinepizza.coupon.Entity.CouponType;
import com.onlinepizza.coupon.Exception.CouponAlreadyExistsException;
import com.onlinepizza.coupon.Exception.CouponIdNotFoundException;
import com.onlinepizza.coupon.Exception.InvalidCouponCodeException;
import com.onlinepizza.coupon.Exception.InvalidCouponOperationException;
import com.onlinepizza.coupon.client.OrderServiceClient;
import com.onlinepizza.coupon.dto.CouponDTO;
import com.onlinepizza.coupon.dto.PizzaOrderDTO;
import com.onlinepizza.coupon.repository.CouponRepository;

@Service
public class CouponServiceImpl implements CouponService {

    private static final Logger logger = LoggerFactory.getLogger(CouponServiceImpl.class); // Logger for the service class

    @Autowired
    private CouponRepository couponRepository;

    @Autowired
    private OrderServiceClient orderServiceClient;

    @Override
    public CouponDTO addCoupons(String code, Integer bookingOrderId) {
        logger.info("Adding coupon with code: {}", code);

        // Validate the coupon code format
        if (!code.matches("^(CODE|COUPON)([1-9][0-9]{0,4})$")) {
            throw new InvalidCouponCodeException("Invalid coupon code. Code should be in the range of CODE1 to CODE99999 or COUPON1 to COUPON99999.");
        }

        // Check if the coupon code already exists
        if (couponRepository.existsByCode(code)) {
            throw new CouponAlreadyExistsException("Coupon code already exists.");
        }

        // Fetch booking order details using Feign client
        ResponseEntity<PizzaOrderDTO> response = orderServiceClient.viewPizzaOrder(bookingOrderId);
        if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null) {
            throw new RuntimeException("Failed to fetch pizza order details or Order not found.");
        }

        PizzaOrderDTO pizzaOrderDTO = response.getBody();
        double totalCost = pizzaOrderDTO.getTotalCost();

        // Calculate final total cost based on the coupon
        double finalTotalCost = calculateFinalTotalCost(totalCost);

        // Determine the coupon type
        CouponType type = determineCouponType(totalCost);

        // Create and save coupon
        Coupon coupon = new Coupon();
        coupon.setCode(code);
        coupon.setBookingOrderId(bookingOrderId);
        coupon.setTotalCost(totalCost);
        coupon.setFinalTotalCost(finalTotalCost);
        coupon.setType(type);
        coupon.setExpiryDate(LocalDate.now().plusDays(30)); // Coupon expires in 30 days

        Coupon savedCoupon = couponRepository.save(coupon);

        logger.info("Coupon added successfully with ID: {}", savedCoupon.getId());

        return convertToDTO(savedCoupon);
    }



    @Override
    public CouponDTO editCoupons(int id, CouponDTO couponDTO) throws InvalidCouponOperationException {
        logger.info("Editing coupon with ID: {}", id);

        // Find the existing coupon by ID
        Coupon coupon = couponRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Coupon not found with ID: {}", id);
                    return new InvalidCouponOperationException("Coupon not found with id: " + id);
                });

        // Update the coupon properties with the values from couponDTO
        if (couponDTO.getCode() == null) {
            logger.error("Coupon code cannot be null for coupon with ID: {}", id);
            throw new InvalidCouponOperationException("Coupon code cannot be null.");
        }

        try {
            coupon.setCode(couponDTO.getCode());
        } catch (IllegalArgumentException e) {
            logger.error("Invalid coupon code: {}", couponDTO.getCode());
            throw new InvalidCouponOperationException("Invalid coupon code: " + couponDTO.getCode());
        }

        // Check if cost is not null and greater than zero
        if (couponDTO.getTotalCost() != null) {
            if (couponDTO.getTotalCost() <= 0) {
                logger.error("Coupon cost must be greater than zero for coupon with ID: {}", id);
                throw new InvalidCouponOperationException("Coupon cost must be greater than zero.");
            }
            coupon.setTotalCost(couponDTO.getTotalCost());
            coupon.setFinalTotalCost(calculateFinalTotalCost(couponDTO.getTotalCost())); // Update total cost
            coupon.setType(determineCouponType(couponDTO.getTotalCost())); // Set type based on cost
        } else {
            logger.error("Coupon cost cannot be null for coupon with ID: {}", id);
            throw new InvalidCouponOperationException("Coupon cost cannot be null.");
        }

        // Set other properties if they are present
        if (couponDTO.getExpiryDate() != null) {
            coupon.setExpiryDate(couponDTO.getExpiryDate());
        }

        // Save the updated coupon to the database
        Coupon updatedCoupon = couponRepository.save(coupon);
        logger.info("Coupon with ID: {} updated successfully", id);

        return convertToDTO(updatedCoupon);
    }

    @Transactional
    @Override
    public void deleteCoupons(int id) throws CouponIdNotFoundException {
        logger.info("Deleting coupon with ID: {}", id);

        // Check if the coupon exists by ID and throw an exception if not
        if (!couponRepository.existsById(id)) {
            logger.error("Coupon ID not found: {}", id);
            throw new CouponIdNotFoundException("Coupon ID not found");
        }

        // Deleting the coupon if it exists
        couponRepository.deleteById(id);
        logger.info("Coupon ID {} deleted successfully", id);
    }

    @Override
    public List<CouponDTO> viewCoupons() {
        logger.info("Fetching all coupons");
        // Fetching all coupons from the repository and converting to DTOs
        return couponRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CouponDTO getCouponById(int id) {
        logger.info("Fetching coupon with ID: {}", id);
        // Fetching a coupon by its ID and converting to DTO
        return couponRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> {
                    logger.error("Coupon with ID: {} not found", id);
                    return new CouponIdNotFoundException("Coupon with ID " + id + " not found");
                });
    }

    private CouponDTO convertToDTO(Coupon coupon) {
        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setId(coupon.getId());
        couponDTO.setCode(coupon.getCode());
        couponDTO.setType(coupon.getType());
        couponDTO.setBookingOrderId(coupon.getBookingOrderId());
        couponDTO.setExpiryDate(coupon.getExpiryDate());
        couponDTO.setTotalCost(coupon.getTotalCost());
        couponDTO.setFinalTotalCost(coupon.getFinalTotalCost());
        return couponDTO;
    }

    private Coupon convertToEntity(CouponDTO couponDTO) {
        Coupon coupon = new Coupon();
        coupon.setId(couponDTO.getId());
        coupon.setCode(couponDTO.getCode());
        coupon.setType(couponDTO.getType());
        coupon.setBookingOrderId(couponDTO.getBookingOrderId());
        coupon.setExpiryDate(couponDTO.getExpiryDate());
        coupon.setTotalCost(couponDTO.getTotalCost());
        coupon.setFinalTotalCost(couponDTO.getFinalTotalCost());
        return coupon;
    }

   

//    // Helper method to determine the coupon type based on the cost
//    private CouponType determineCouponType(double totalCost) {
//        if (totalCost <= 1500) {
//            return CouponType.PERCENTAGE_DISCOUNT_TYPE;  // Percentage discount for cost <= 1500
//        } else {
//            return CouponType.FIXED_AMOUNT_TYPE;  // Fixed discount for cost > 1500
//        }
//    }



	
		@Override
		public CouponDTO addCoupons(String code, int bookingOrderId) {

		    logger.info("Adding coupon with code: {} for BookingOrderId: {}", code, bookingOrderId);

		    // Validate if coupon code matches the correct pattern
		    if (!code.matches("^(CODE|COUPON)([1-9][0-9]{0,4})$")) {
		        throw new InvalidCouponCodeException("Invalid coupon code. Code should follow the format CODE1 to CODE99999 or COUPON1 to COUPON99999.");
		    }

		    // Check if the coupon already exists
		    if (couponRepository.existsByCode(code)) {
		        throw new CouponAlreadyExistsException("Coupon with this code already exists.");
		    }

		    // Fetch PizzaOrder details using Feign client
		    ResponseEntity<PizzaOrderDTO> response = orderServiceClient.viewPizzaOrder(bookingOrderId);
		    if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
		        throw new RuntimeException("Failed to fetch pizza order details for bookingOrderId: " + bookingOrderId);
		    }

		    PizzaOrderDTO pizzaOrder = response.getBody();
		    double totalCost = pizzaOrder.getTotalCost();

		    // Calculate the final total cost after applying the coupon
		    double finalTotalCost = calculateFinalTotalCost(totalCost);
		    CouponType couponType = determineCouponType(totalCost);

		    // Create a new Coupon entity
		    Coupon coupon = new Coupon();
		    coupon.setCode(code);
		    coupon.setBookingOrderId(bookingOrderId);
		    coupon.setTotalCost(totalCost);
		    coupon.setFinalTotalCost(finalTotalCost);
		    coupon.setType(couponType);
		    coupon.setExpiryDate(java.time.LocalDate.now().plusDays(30));

		    // Save the coupon to the database
		    Coupon savedCoupon = couponRepository.save(coupon);
		    logger.info("Coupon added successfully with ID: {}", savedCoupon.getId());

		    // Convert and return the result as DTO
		    return convertToDTO(savedCoupon);
		}

		// Calculate finalTotalCost based on coupon type and cost
		private double calculateFinalTotalCost(double totalCost) {
		    if (totalCost <= 300) {
		        return totalCost;  // No discount
		    } else if (totalCost <= 600) {
		        return totalCost * 0.95;  // 5% discount
		    } else if (totalCost <= 1000) {
		        return totalCost * 0.88;  // 12% discount
		    } else if (totalCost <= 1500) {
		        return totalCost * 0.75;  // 25% discount
		    } else {
		        return totalCost - 700;  // Fixed ₹700 discount
		    }
		}

		// Determine coupon type
		private CouponType determineCouponType(double totalCost) {
		    return (totalCost <= 1500) ? CouponType.PERCENTAGE_DISCOUNT_TYPE : CouponType.FIXED_AMOUNT_TYPE;
		}

		

	
}
