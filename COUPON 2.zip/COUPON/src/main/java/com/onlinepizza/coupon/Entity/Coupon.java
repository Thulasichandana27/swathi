package com.onlinepizza.coupon.Entity;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "coupons")
public class Coupon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;


    @Column(name = "code", nullable = false)
    private String code;

    @Column(name = "bookingOrderId", nullable = false)
    private Integer bookingOrderId;
   
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private CouponType type;

    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    
     // Changed from double to Double

    @Column(name = "total_cost", nullable = false)
    private Double totalCost;
    
    @Column(name="final_total_cost",nullable=false)
    private Double finalTotalCost;
}



///change

