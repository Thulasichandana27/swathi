package com.onlinepizza.coupon.Entity;

import java.util.regex.Pattern;

public enum CouponCode {

    CODE("CODE"),
    COUPON("COUPON");

    private final String prefix;

    CouponCode(String prefix) {
        this.prefix = prefix;
    }

    // Regular expression for validating the code pattern (CODE1 to CODE99999, COUPON1 to COUPON99999)
    private static final Pattern VALID_CODE_PATTERN = Pattern.compile("^(CODE|COUPON)\\d{1,5}$");

    // Method to check if a given coupon code matches the pattern
    public static boolean isValidCode(String code) {
        if (code == null) {
            return false;
        }
        return VALID_CODE_PATTERN.matcher(code).matches();
    }

    public String getPrefix() {
        return prefix;
    }
}
