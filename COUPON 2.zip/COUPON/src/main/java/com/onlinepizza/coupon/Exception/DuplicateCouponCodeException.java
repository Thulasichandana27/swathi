package com.onlinepizza.coupon.Exception;

public class DuplicateCouponCodeException extends RuntimeException {
    public DuplicateCouponCodeException(String message) {
        super(message);
    }
}
