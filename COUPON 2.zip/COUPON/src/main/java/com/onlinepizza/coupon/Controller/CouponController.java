

package com.onlinepizza.coupon.Controller;

import com.onlinepizza.coupon.Exception.CouponAlreadyExistsException;
import com.onlinepizza.coupon.Exception.CouponIdNotFoundException;
import com.onlinepizza.coupon.Exception.InvalidCouponCodeException;
import com.onlinepizza.coupon.Exception.InvalidCouponOperationException;
import com.onlinepizza.coupon.dto.CouponDTO;
import com.onlinepizza.coupon.service.CouponService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/coupons")
public class CouponController {

    private static final Logger logger = LoggerFactory.getLogger(CouponController.class);

    @Autowired
    private CouponService couponService;

    @PostMapping
    public ResponseEntity<?> addCoupons(@RequestBody @Valid CouponDTO requestDTO) {
        try {
            CouponDTO createdCoupon = couponService.addCoupons(requestDTO.getCode(), requestDTO.getBookingOrderId());
            return ResponseEntity.status(HttpStatus.CREATED).body(createdCoupon);
        } catch (CouponAlreadyExistsException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonMap("message", e.getMessage()));
        } catch (InvalidCouponCodeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonMap("message", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("message", e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<CouponDTO> editCoupon(@PathVariable int id, @Valid @RequestBody CouponDTO couponDTO) throws InvalidCouponOperationException {
        logger.info("Attempting to update coupon with ID: {}", id);
        
        // Call the service to update the coupon
        CouponDTO updatedCoupon = couponService.editCoupons(id, couponDTO);
        
        logger.info("Coupon with ID: {} updated successfully", id);
        // Return the updated coupon with HTTP status 200 OK
        return new ResponseEntity<>(updatedCoupon, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCoupon(@PathVariable int id) {
        try {
            logger.info("Attempting to delete coupon with ID: {}", id);
            
            couponService.deleteCoupons(id);
            logger.info("Coupon with ID: {} deleted successfully", id);
            
            return new ResponseEntity<>("Coupon deleted successfully", HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Failed to delete coupon with ID: {}. Error: {}", id, e.getMessage());
            return new ResponseEntity<>("Coupon not found", HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<CouponDTO>> viewCoupons() {
        logger.info("Fetching all coupons...");
        
        List<CouponDTO> coupons = couponService.viewCoupons();
        logger.info("Fetched {} coupons", coupons.size());
        
        return new ResponseEntity<>(coupons, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getCouponById(@PathVariable int id) {
        logger.info("Fetching coupon with ID: {}", id);
        
        try {
            // Call the service to get the coupon by ID
            CouponDTO coupon = couponService.getCouponById(id);
            
            logger.info("Coupon with ID: {} found", id);
            // Return the coupon if found with HTTP status 200 (OK)
            return ResponseEntity.ok(coupon);
        } catch (CouponIdNotFoundException e) {
            // Return HTTP status 404 (Not Found) with the exception message in the body
            logger.error("Coupon with ID: {} not found. Error: {}", id, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    // Global exception handler to handle validation exceptions
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        logger.error("Validation failed for the request body. Errors: {}", ex.getBindingResult().getAllErrors());
        
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}

////////////----














