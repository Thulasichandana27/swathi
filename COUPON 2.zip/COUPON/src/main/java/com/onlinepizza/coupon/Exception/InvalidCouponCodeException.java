package com.onlinepizza.coupon.Exception;

public class InvalidCouponCodeException extends RuntimeException {

    // Constructor to pass a custom error message when the exception is thrown
    public InvalidCouponCodeException(String message) {
        super(message);
    }
}
