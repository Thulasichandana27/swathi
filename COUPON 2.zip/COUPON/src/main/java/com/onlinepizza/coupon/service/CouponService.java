package com.onlinepizza.coupon.service;

import com.onlinepizza.coupon.Entity.Coupon;
import com.onlinepizza.coupon.Exception.CouponIdNotFoundException;
import com.onlinepizza.coupon.Exception.InvalidCouponOperationException;
import com.onlinepizza.coupon.dto.CouponDTO;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;


public interface CouponService {

    // Method to add a new coupon
    //CouponDTO addCoupons(CouponDTO couponDTO);

    // Method to edit an existing coupon by ID
    CouponDTO editCoupons(int id, CouponDTO couponDTO) throws InvalidCouponOperationException;

    // Method to delete a coupon by ID
    void deleteCoupons(int id) throws CouponIdNotFoundException;

    // Method to view all coupons
    List<CouponDTO> viewCoupons();

    // Method to get a coupon by its ID
    CouponDTO getCouponById(int id);

	CouponDTO addCoupons(String code, int bookingOrderId);

	CouponDTO addCoupons(String code, Integer bookingOrderId);
}


///change