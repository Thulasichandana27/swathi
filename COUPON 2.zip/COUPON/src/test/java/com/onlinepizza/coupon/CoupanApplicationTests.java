package com.onlinepizza.coupon;

import com.onlinepizza.coupon.Entity.Coupon;
import com.onlinepizza.coupon.Exception.CouponAlreadyExistsException;
import com.onlinepizza.coupon.Exception.CouponIdNotFoundException;
import com.onlinepizza.coupon.Exception.InvalidCouponCodeException;
import com.onlinepizza.coupon.Exception.InvalidCouponOperationException;
import com.onlinepizza.coupon.dto.CouponDTO;
import com.onlinepizza.coupon.repository.CouponRepository;
import com.onlinepizza.coupon.service.CouponServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CoupanApplicationTests {

    @Mock
    private CouponRepository couponRepository;

    @InjectMocks
    private CouponServiceImpl couponService;

    private CouponDTO couponDTO;

    @BeforeEach
    void setUp() {
        couponDTO = new CouponDTO();
        couponDTO.setCode("COUPON123");
        couponDTO.setTotalCost(500.0);
        couponDTO.setExpiryDate(LocalDate.now().plusDays(30));
    }

   /* @Test
    void testAddCoupon_Success() {
        when(couponRepository.existsByCode(couponDTO.getCode())).thenReturn(false);
        when(couponRepository.save(any(Coupon.class))).thenReturn(new Coupon());

        CouponDTO savedCoupon = couponService.addCoupons(couponDTO);

        assertNotNull(savedCoupon);
        assertEquals("COUPON123", savedCoupon.getCode());
        verify(couponRepository, times(1)).save(any(Coupon.class));
    }*/

    @Test
    void testAddCoupon_CodeAlreadyExists() {
        String code = "CODE123";
        int bookingOrderId = 1;

        when(couponRepository.existsByCode(code)).thenReturn(true);

        assertThrows(CouponAlreadyExistsException.class, () -> couponService.addCoupons(code, bookingOrderId));

        // Ensure that save() method is never called
        verify(couponRepository, never()).save(any(Coupon.class));
    }
}
//
//    @Test
//    void testEditCoupon_Success() {
//        Coupon existingCoupon = new Coupon();
//        existingCoupon.setId(1L);
//        existingCoupon.setCode("COUPON123");
//        existingCoupon.setTotalCost(500.0);
//        existingCoupon.setFinalTotalCost(500.0);
//        existingCoupon.setExpiryDate(LocalDate.now().plusDays(30));
//
//        when(couponRepository.findById(1L)).thenReturn(Optional.of(existingCoupon));
//        when(couponRepository.save(any(Coupon.class))).thenReturn(existingCoupon);
//
//        couponDTO.setTotalCost(600.0);
//        CouponDTO updatedCoupon = couponService.editCoupons(1L, couponDTO);
//
//        assertNotNull(updatedCoupon);
//        assertEquals(600.0, updatedCoupon.getTotalCost());
//        verify(couponRepository, times(1)).save(any(Coupon.class));
//    }
//
//    @Test
//    void testEditCoupon_CouponNotFound() {
//        when(couponRepository.findById(1L)).thenReturn(Optional.empty());
//
//        assertThrows(InvalidCouponOperationException.class, () -> couponService.editCoupons(1L, couponDTO));
//    }
//
//   /* @Test
//    void testEditCoupon_InvalidCouponCode() {
//        Coupon existingCoupon = new Coupon();
//        existingCoupon.setId(1L);
//        existingCoupon.setCode("COUPON123");
//
//        when(couponRepository.findById(1L)).thenReturn(Optional.of(existingCoupon));
//
//        couponDTO.setCode("INVALIDCODE");
//        assertThrows(InvalidCouponOperationException.class, () -> couponService.editCoupons(1L, couponDTO));
//    }*/
//
//    @Test
//    void testDeleteCoupon_Success() {
//        when(couponRepository.existsById(1L)).thenReturn(true);
//
//        couponService.deleteCoupons(1L);
//
//        verify(couponRepository, times(1)).deleteById(1L);
//    }
//
//    @Test
//    void testDeleteCoupon_CouponNotFound() {
//        when(couponRepository.existsById(1L)).thenReturn(false);
//
//        assertThrows(CouponIdNotFoundException.class, () -> couponService.deleteCoupons(1L));
//        verify(couponRepository, never()).deleteById(1L);
//    }
//
//    @Test
//    void testViewCoupons_Success() {
//        Coupon coupon = new Coupon();
//        coupon.setId(1L);
//        coupon.setCode("COUPON123");
//        coupon.setTotalCost(500.0);
//
//        when(couponRepository.findAll()).thenReturn(java.util.List.of(coupon));
//
//        var coupons = couponService.viewCoupons();
//        assertFalse(coupons.isEmpty());
//        assertEquals(1, coupons.size());
//        assertEquals("COUPON123", coupons.get(0).getCode());
//    }
//
//    @Test
//    void testGetCouponById_Success() {
//        Coupon coupon = new Coupon();
//        coupon.setId(1L);
//        coupon.setCode("COUPON123");
//        coupon.setTotalCost(500.0);
//
//        when(couponRepository.findById(1L)).thenReturn(Optional.of(coupon));
//
//        CouponDTO couponDTO = couponService.getCouponById(1L);
//
//        assertNotNull(couponDTO);
//        assertEquals("COUPON123", couponDTO.getCode());
//    }
//
//    @Test
//    void testGetCouponById_CouponNotFound() {
//        when(couponRepository.findById(1L)).thenReturn(Optional.empty());
//
//        assertThrows(CouponIdNotFoundException.class, () -> couponService.getCouponById(1L));
//    }
//}
