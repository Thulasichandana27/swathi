package com.onlinepizza.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import com.onlinepizza.client.PizzaServiceClient;
import com.onlinepizza.dto.PizzaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinepizza.dto.PizzaOrderDTO;
import com.onlinepizza.exception.OrderIdNotFoundException;
import com.onlinepizza.model.PizzaOrder;
import com.onlinepizza.repository.IPizzaOrderRepository;

import jakarta.validation.Valid;

@Service
public class PizzaOrderServiceImpl implements IPizzaOrderService {

	@Autowired
	private IPizzaOrderRepository pizzaOrderRepository;

	@Autowired
	private PizzaServiceClient pizzaServiceClient;

	@Override
	public PizzaOrderDTO bookPizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO) {
		/*.setDateOfOrder(LocalDate.from(LocalDateTime.now())); // Set current date and time for the order

		PizzaOrder pizzaOrder = convertToEntity(pizzaOrderDTO);
		// Save the order in the database
		pizzaOrder.setTotalCost(calculateTotalCost(pizzaOrder.getPizzaId(), pizzaOrder.getQuantity()));
		PizzaOrder savedOrder = pizzaOrderRepository.save(pizzaOrder);
		// Convert Entity back to DTO
		return convertToDTO(savedOrder);*/
		// Fetch the existing order with the same pizzaId
		PizzaOrder existingOrder = pizzaOrderRepository.findByPizzaId(pizzaOrderDTO.getPizzaId());

		PizzaOrder pizzaOrder;

		if (existingOrder != null) {
			// If an order with the same pizzaId exists, reuse the existing order
			pizzaOrder = existingOrder;
			pizzaOrder.setQuantity(pizzaOrderDTO.getQuantity()); // Update the quantity
			pizzaOrder.setDateOfOrder(LocalDate.from(LocalDateTime.now())); // Update the date of the order
			pizzaOrder.setTotalCost(calculateTotalCost(pizzaOrder.getPizzaId(), pizzaOrder.getQuantity())); // Recalculate total cost
		} else {
			// If no existing order exists with the same pizzaId, create a new one
			pizzaOrder = convertToEntity(pizzaOrderDTO);
			pizzaOrder.setDateOfOrder(LocalDate.from(LocalDateTime.now())); // Set current date and time
			pizzaOrder.setTotalCost(calculateTotalCost(pizzaOrder.getPizzaId(), pizzaOrder.getQuantity())); // Calculate total cost
		}

// Save the order (either new or updated)
		PizzaOrder savedOrder = pizzaOrderRepository.save(pizzaOrder);

// Convert Entity back to DTO and return
		return convertToDTO(savedOrder);

	}

	@Override
	public PizzaOrderDTO updatePizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO) {
		PizzaOrder existingOrder = pizzaOrderRepository.findById(pizzaOrderDTO.getBookingOrderId())
				.orElseThrow(() -> new RuntimeException("Pizza order not found with ID: " + pizzaOrderDTO.getBookingOrderId()));

		// Update the existing order using DTO values
		PizzaOrder updatedOrder = convertToEntity(pizzaOrderDTO);
		updatedOrder.setTotalCost(calculateTotalCost(updatedOrder.getPizzaId(), updatedOrder.getQuantity()));
		updatedOrder.setBookingOrderId(existingOrder.getBookingOrderId()); // Preserve ID

		// Save the updated order and return as DTO
		return convertToDTO(pizzaOrderRepository.save(updatedOrder));

	}

	@Override
	public PizzaOrderDTO cancelPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException {
		PizzaOrder existingOrder = pizzaOrderRepository.findById(bookingOrderId)
				.orElseThrow(() -> new OrderIdNotFoundException("No pizza order found with Booking Order ID: " + bookingOrderId));

		// Convert entity to DTO before deletion
		PizzaOrderDTO deletedOrderDTO = convertToDTO(existingOrder);

		// Delete the order from the database
		pizzaOrderRepository.deleteById(bookingOrderId);

		System.out.println("Order ID " + bookingOrderId + " deleted successfully.");

		// Return details of the deleted order
		return deletedOrderDTO;
	}

	@Override
	public PizzaOrderDTO viewPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException {
		// Fetch the pizza order using orderId (as a reference, not primary key)
		PizzaOrder existingOrder = pizzaOrderRepository.findById(bookingOrderId)
				.orElseThrow(() -> new OrderIdNotFoundException("No pizza order found with Booking Order ID: " + bookingOrderId));

		// Convert entity to DTO and return
		return convertToDTO(existingOrder);
	}

	public Double calculateTotalCost(int pizzaId, int quantity) {
		double totalCost = 0;
			PizzaDTO pizza = pizzaServiceClient.viewPizza(pizzaId);
			totalCost += pizza.getPizzaCost() * quantity;
		return totalCost;
	}

	private PizzaOrder convertToEntity(PizzaOrderDTO pizzaOrderDTO) {
		PizzaOrder pizzaOrder = new PizzaOrder();
		pizzaOrder.setPizzaId(pizzaOrderDTO.getPizzaId());
		pizzaOrder.setDateOfOrder(pizzaOrderDTO.getDateOfOrder());
		pizzaOrder.setQuantity(pizzaOrderDTO.getQuantity());
		pizzaOrder.setTotalCost(pizzaOrderDTO.getTotalCost());
		return pizzaOrder;
	}

	private PizzaOrderDTO convertToDTO(PizzaOrder pizzaOrder) {
		PizzaOrderDTO pizzaOrderDTO = new PizzaOrderDTO();
		pizzaOrderDTO.setBookingOrderId(pizzaOrder.getBookingOrderId());
		pizzaOrderDTO.setPizzaId(pizzaOrder.getPizzaId());
		pizzaOrderDTO.setDateOfOrder(pizzaOrder.getDateOfOrder());
		pizzaOrderDTO.setQuantity(pizzaOrder.getQuantity());
		pizzaOrderDTO.setTotalCost(pizzaOrder.getTotalCost());
		return pizzaOrderDTO;
	}
}