package com.onlinepizza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.onlinepizza.dto.PizzaOrderDTO;
import com.onlinepizza.exception.InvalidSizeException;
import com.onlinepizza.exception.OrderIdNotFoundException;
import com.onlinepizza.service.IPizzaOrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/pizza-orders")
public class PizzaOrderController {

    @Autowired
    private IPizzaOrderService pizzaOrderService;

    @PostMapping("/create")
    public ResponseEntity<PizzaOrderDTO> bookPizzaOrder(@RequestBody @Valid PizzaOrderDTO pizzaOrderDTO) {
        PizzaOrderDTO createdPizzaOrder = pizzaOrderService.bookPizzaOrder(pizzaOrderDTO);
        return new ResponseEntity<>(createdPizzaOrder, HttpStatus.CREATED);
    }

    @PutMapping("/{bookingOrderId}")
    public ResponseEntity<PizzaOrderDTO> updatePizzaOrder(@PathVariable int bookingOrderId, @RequestBody @Valid PizzaOrderDTO pizzaOrderDTO) {
        pizzaOrderDTO.setBookingOrderId(bookingOrderId);
        PizzaOrderDTO updatedPizzaOrder = pizzaOrderService.updatePizzaOrder(pizzaOrderDTO);
        return new ResponseEntity<>(updatedPizzaOrder, HttpStatus.OK);
    }

    @DeleteMapping("/{bookingOrderId}")
    public ResponseEntity<String> cancelPizzaOrder(@PathVariable int bookingOrderId) throws OrderIdNotFoundException {
        pizzaOrderService.cancelPizzaOrder(bookingOrderId);
        return new ResponseEntity<>("Order with ID "+bookingOrderId+" deleted successfully",HttpStatus.OK);
    }

    @GetMapping("/{bookingOrderId}")
    public ResponseEntity<PizzaOrderDTO> viewPizzaOrder(@PathVariable int bookingOrderId) throws OrderIdNotFoundException {
        PizzaOrderDTO pizzaOrderDTO = pizzaOrderService.viewPizzaOrder(bookingOrderId);
        return new ResponseEntity<>(pizzaOrderDTO, HttpStatus.OK);
    }

//    @GetMapping("/calculate-total")
//    public ResponseEntity<List<PizzaOrderDTO>> calculateTotal(@RequestParam String size, @RequestParam int quantity) throws InvalidSizeException {
//        List<PizzaOrderDTO> pizzaOrders = pizzaOrderService.calculateTotal(size, quantity);
//        return new ResponseEntity<>(pizzaOrders, HttpStatus.OK);
//    }
}

