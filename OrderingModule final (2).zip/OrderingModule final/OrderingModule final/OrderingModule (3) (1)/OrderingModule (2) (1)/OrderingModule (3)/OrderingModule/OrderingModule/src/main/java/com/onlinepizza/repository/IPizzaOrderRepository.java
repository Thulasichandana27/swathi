package com.onlinepizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlinepizza.model.PizzaOrder;

import java.util.Optional;

@Repository
public interface IPizzaOrderRepository extends JpaRepository<PizzaOrder,Integer> {


    PizzaOrder findByPizzaId(int pizzaId);
}
