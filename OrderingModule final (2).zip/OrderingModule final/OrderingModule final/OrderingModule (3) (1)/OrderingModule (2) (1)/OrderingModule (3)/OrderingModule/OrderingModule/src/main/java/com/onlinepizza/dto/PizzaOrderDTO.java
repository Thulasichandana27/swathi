package com.onlinepizza.dto;

import java.time.LocalDate;

//import com.onlinepizza.model.PizzaSize;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

@AllArgsConstructor

public class PizzaOrderDTO {

	private Integer bookingOrderId;

	@NotNull(message = "{pizzaId.notnull}")
	@Positive(message = "{pizzaId.positive}")
	private Integer pizzaId;

	//@PastOrPresent(message = "{dateOfOrder.pastOrPresent}")
	private LocalDate dateOfOrder;

	@NotNull(message = "{quantity.notnull}")
	@Positive(message = "{quantity.positive}")
	@Range(min=1,max=200)
	private Integer quantity;


	private Double totalCost;

	// Getters and Setters
	public int getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(int bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public LocalDate getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(LocalDate dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public PizzaOrderDTO() {
		this.dateOfOrder=LocalDate.now();
	}
}
