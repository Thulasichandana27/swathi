package com.onlinepizza.dto;

public class User {



}
