package com.onlinepizza.controller;

import com.onlinepizza.dto.OrderLineDTO;
import com.onlinepizza.service.OrderLineServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order-lines")
public class OrderLineController {

    @Autowired
    private OrderLineServiceImpl orderLineService;

    // Get all order lines
    @GetMapping
    public ResponseEntity<List<OrderLineDTO>> getAllOrderLines() {
        List<OrderLineDTO> orderLines = orderLineService.getAllOrderLines();
        return new ResponseEntity<>(orderLines, HttpStatus.OK);
    }

    // Get order lines for a specific pizza order
    @GetMapping("/pizza-order/{pizzaOrderId}")
    public ResponseEntity<List<OrderLineDTO>> getOrderLinesForPizzaOrder(@PathVariable Long pizzaOrderId) {
        List<OrderLineDTO> orderLines = orderLineService.getOrderLinesForPizzaOrder(pizzaOrderId);
        return new ResponseEntity<>(orderLines, HttpStatus.OK);
    }

    // Get a specific order line by ID
    @GetMapping("/{id}")
    public ResponseEntity<OrderLineDTO> getOrderLineById(@PathVariable Long id) {
        OrderLineDTO orderLineDTO = orderLineService.getOrderLineById(id);
        if (orderLineDTO != null) {
            return new ResponseEntity<>(orderLineDTO, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create a new order line
    @PostMapping
    public ResponseEntity<OrderLineDTO> createOrderLine(@RequestBody OrderLineDTO orderLineDTO) {
        OrderLineDTO createdOrderLine = orderLineService.saveOrderLine(orderLineDTO);
        return new ResponseEntity<>(createdOrderLine, HttpStatus.CREATED);
    }

    // Update an existing order line
    @PutMapping("/{id}")
    public ResponseEntity<OrderLineDTO> updateOrderLine(@PathVariable Long id, @RequestBody OrderLineDTO orderLineDTO) {
        OrderLineDTO updatedOrderLine = orderLineService.updateOrderLine(id, orderLineDTO);
        if (updatedOrderLine != null) {
            return new ResponseEntity<>(updatedOrderLine, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete an order line
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrderLine(@PathVariable Long id) {
        orderLineService.deleteOrderLine(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
