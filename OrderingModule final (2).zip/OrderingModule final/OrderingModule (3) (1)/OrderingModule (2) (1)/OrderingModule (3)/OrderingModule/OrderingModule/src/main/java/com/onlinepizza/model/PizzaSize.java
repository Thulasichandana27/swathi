//package com.onlinepizza.model;
//
//public enum PizzaSize {
//    SMALL,MEDIUM,LARGE
//}
