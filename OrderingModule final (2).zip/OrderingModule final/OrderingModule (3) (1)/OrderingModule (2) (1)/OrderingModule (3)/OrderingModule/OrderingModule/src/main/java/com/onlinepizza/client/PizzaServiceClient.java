package com.onlinepizza.client;

import com.onlinepizza.dto.Pizza;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="Pizza-module")
public interface PizzaServiceClient {

    @GetMapping("/pizzas/view/{pizzaId}")
    Pizza viewPizza(@PathVariable(name="pizzaId") int pizzaId);
    }

