package com.onlinepizza.service;

import com.onlinepizza.dto.OrderLineDTO;
import java.util.List;

public interface IOrderLineService {

    OrderLineDTO getOrderLineById(Long id);

    List<OrderLineDTO> getAllOrderLines();

    List<OrderLineDTO> getOrderLinesForPizzaOrder(Long pizzaOrderId);

    OrderLineDTO saveOrderLine(OrderLineDTO orderLineDTO);

    OrderLineDTO updateOrderLine(Long id, OrderLineDTO orderLineDTO);

    void deleteOrderLine(Long id);
}
