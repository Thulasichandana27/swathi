package com.onlinepizza.dto;

public class OrderLineDTO {

    private Long orderLineId;
    private Integer quantity;
    private Long pizzaOrderId;  // A reference to the PizzaOrder (foreign key)

    public OrderLineDTO(Long orderLineId, Integer quantity, Long bookingOrderId) {
    }

    // Getters and Setters
    public Long getOrderLineId() {
        return orderLineId;
    }

    public void setOrderLineId(Long orderLineId) {
        this.orderLineId = orderLineId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Long getPizzaOrderId() {
        return pizzaOrderId;
    }

    public void setPizzaOrderId(Long pizzaOrderId) {
        this.pizzaOrderId = pizzaOrderId;
    }
}
