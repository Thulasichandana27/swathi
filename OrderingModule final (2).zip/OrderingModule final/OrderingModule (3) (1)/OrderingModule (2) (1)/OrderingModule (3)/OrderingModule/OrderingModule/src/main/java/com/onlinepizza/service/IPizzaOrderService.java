package com.onlinepizza.service;

import com.onlinepizza.dto.PizzaOrderDTO;
import java.util.List;

public interface IPizzaOrderService {

	PizzaOrderDTO getPizzaOrderById(Long id);

	List<PizzaOrderDTO> getAllPizzaOrders();

	PizzaOrderDTO savePizzaOrder(PizzaOrderDTO pizzaOrderDTO);

	PizzaOrderDTO updatePizzaOrder(Long id, PizzaOrderDTO pizzaOrderDTO);

	void deletePizzaOrder(Long id);
}
