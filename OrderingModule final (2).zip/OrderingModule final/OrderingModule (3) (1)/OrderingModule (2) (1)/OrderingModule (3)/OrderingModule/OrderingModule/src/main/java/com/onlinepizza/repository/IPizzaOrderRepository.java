package com.onlinepizza.repository;

import com.onlinepizza.model.PizzaOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IPizzaOrderRepository extends JpaRepository<PizzaOrder, Long> {
    // You can add custom queries here if necessary, for example:
    // List<PizzaOrder> findByPizzaId(Long pizzaId);
}
