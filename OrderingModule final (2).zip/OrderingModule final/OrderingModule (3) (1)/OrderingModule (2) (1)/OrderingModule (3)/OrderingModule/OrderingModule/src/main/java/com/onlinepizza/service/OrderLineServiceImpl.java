package com.onlinepizza.service;

import com.onlinepizza.dto.OrderLineDTO;
import com.onlinepizza.model.OrderLine;
import com.onlinepizza.repository.IOrderLineRepository;
import com.onlinepizza.service.IOrderLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderLineServiceImpl implements IOrderLineService {

    @Autowired
    private IOrderLineRepository orderLineRepository;

    @Override
    public OrderLineDTO getOrderLineById(Long id) {
        OrderLine orderLine = orderLineRepository.findById(id).orElse(null);
        return convertToDTO(orderLine);
    }

    @Override
    public List<OrderLineDTO> getAllOrderLines() {
        List<OrderLine> orderLines = orderLineRepository.findAll();
        return orderLines.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<OrderLineDTO> getOrderLinesForPizzaOrder(Long pizzaOrderId) {
        List<OrderLine> orderLines = orderLineRepository.findByPizzaOrderBookingOrderId(pizzaOrderId);
        return orderLines.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public OrderLineDTO saveOrderLine(OrderLineDTO orderLineDTO) {
        OrderLine orderLine = convertToEntity(orderLineDTO);
        orderLine = orderLineRepository.save(orderLine);
        return convertToDTO(orderLine);
    }

    @Override
    public OrderLineDTO updateOrderLine(Long id, OrderLineDTO orderLineDTO) {
        OrderLine orderLine = convertToEntity(orderLineDTO);
        orderLine.setOrderLineId(id);  // Ensure that the ID is set correctly
        orderLine = orderLineRepository.save(orderLine);
        return convertToDTO(orderLine);
    }

    @Override
    public void deleteOrderLine(Long id) {
        orderLineRepository.deleteById(id);
    }

    // Helper methods to convert between DTO and Entity
    private OrderLineDTO convertToDTO(OrderLine orderLine) {
        if (orderLine == null) {
            return null;
        }
        return new OrderLineDTO(orderLine.getOrderLineId(), orderLine.getQuantity(), orderLine.getPizzaOrder().getBookingOrderId());
    }

    private OrderLine convertToEntity(OrderLineDTO orderLineDTO) {
        if (orderLineDTO == null) {
            return null;
        }
        OrderLine orderLine = new OrderLine();
        orderLine.setOrderLineId(orderLineDTO.getOrderLineId());
        orderLine.setQuantity(orderLineDTO.getQuantity());
        // Set the PizzaOrder entity by ID or other means if needed
        return orderLine;
    }
}
