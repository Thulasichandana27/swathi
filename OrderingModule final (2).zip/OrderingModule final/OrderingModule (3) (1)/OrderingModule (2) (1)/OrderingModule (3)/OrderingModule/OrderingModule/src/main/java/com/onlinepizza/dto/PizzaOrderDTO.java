package com.onlinepizza.dto;

import java.time.LocalDate;
import java.util.List;

public class PizzaOrderDTO {

	private Long bookingOrderId;
	private Long pizzaId;
	private LocalDate dateOfOrder;
	private Double totalCost;
	private List<OrderLineDTO> orderLines;

	// Getters and Setters
	public Long getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(Long bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public Long getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(Long pizzaId) {
		this.pizzaId = pizzaId;
	}

	public LocalDate getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(LocalDate dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public List<OrderLineDTO> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<OrderLineDTO> orderLines) {
		this.orderLines = orderLines;
	}
}
