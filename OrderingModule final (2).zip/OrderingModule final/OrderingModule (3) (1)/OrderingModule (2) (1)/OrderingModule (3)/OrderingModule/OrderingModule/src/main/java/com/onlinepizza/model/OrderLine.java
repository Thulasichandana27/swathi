package com.onlinepizza.model;

import jakarta.persistence.*;

@Entity
public class OrderLine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "orderline_id")
    private Long orderLineId;

    @Column(name = "quantity")
    private Integer quantity;

    @ManyToOne
    @JoinColumn(name = "pizza_order_id")  // Foreign key column in OrderLine referencing PizzaOrder
    private PizzaOrder pizzaOrder;  // This is the mapped property referenced by PizzaOrder

    // Getters and Setters
    public Long getOrderLineId() {
        return orderLineId;
    }

    public void setOrderLineId(Long orderLineId) {
        this.orderLineId = orderLineId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public PizzaOrder getPizzaOrder() {
        return pizzaOrder;
    }

    // This should accept a PizzaOrder entity, not a PizzaOrderDTO
    public void setPizzaOrder(PizzaOrder pizzaOrder) {
        this.pizzaOrder = pizzaOrder;
    }
}
