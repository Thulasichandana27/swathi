package com.onlinepizza.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pizza_orders")
public class PizzaOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_order_id")
    private Long bookingOrderId;

    @Column(name = "pizza_id")
    private Long pizzaId;

    @Column(nullable = false)
    private LocalDate dateOfOrder;

    @OneToMany(mappedBy = "pizzaOrder", cascade = CascadeType.ALL, orphanRemoval = true) // Make sure to cascade saves and deletes
    private List<OrderLine> orderLines = new ArrayList<>(); // Initialize with an empty list

    private Double totalCost;

    // Getters and Setters (You don't really need them if you're using Lombok)
    public Long getBookingOrderId() {
        return bookingOrderId;
    }

    public void setBookingOrderId(Long bookingOrderId) {
        this.bookingOrderId = bookingOrderId;
    }

    public Long getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(Long pizzaId) {
        this.pizzaId = pizzaId;
    }

    public LocalDate getDateOfOrder() {
        return dateOfOrder;
    }

    public void setDateOfOrder(LocalDate dateOfOrder) {
        this.dateOfOrder = dateOfOrder;
    }

    public List<OrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(List<OrderLine> orderLines) {
        this.orderLines = orderLines;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }
}
