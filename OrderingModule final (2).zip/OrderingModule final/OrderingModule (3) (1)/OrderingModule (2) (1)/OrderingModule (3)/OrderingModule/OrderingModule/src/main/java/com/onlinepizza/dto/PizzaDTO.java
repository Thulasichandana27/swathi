package com.onlinepizza.dto;

public class PizzaDTO {

    private int pizzaId;    
    private String pizzaType;       
    private String pizzaName;      
    private String pizzaDescription;     
    double pizzaCost;     
    private double pizzaCostAfterCoupon;  // Corrected the spelling from 'Coupan' to 'Coupon'

    // Getters and Setters
    public int getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(int pizzaId) {
        this.pizzaId = pizzaId;
    }

    public String getPizzaType() {
        return pizzaType;
    }

    public void setPizzaType(String pizzaType) {
        this.pizzaType = pizzaType;
    }

    public String getPizzaName() {
        return pizzaName;
    }

    public void setPizzaName(String pizzaName) {
        this.pizzaName = pizzaName;
    }

    public String getPizzaDescription() {
        return pizzaDescription;
    }

    public void setPizzaDescription(String pizzaDescription) {
        this.pizzaDescription = pizzaDescription;
    }

    public double getPizzaCost() {
        return pizzaCost;
    }

    public void setPizzaCost(double pizzaCost) {
        this.pizzaCost = pizzaCost;
    }

    public double getPizzaCostAfterCoupon() {
        return pizzaCostAfterCoupon;
    }

    public void setPizzaCostAfterCoupon(double pizzaCostAfterCoupon) {
        this.pizzaCostAfterCoupon = pizzaCostAfterCoupon;
    }
}