package com.onlinepizza.repository;

import com.onlinepizza.model.OrderLine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IOrderLineRepository extends JpaRepository<OrderLine, Long> {
    // You can add custom queries here if necessary, for example:
    // List<OrderLine> findByPizzaOrderId(Long pizzaOrderId);

    // Find OrderLines by pizzaOrderId
    List<OrderLine> findByPizzaOrderBookingOrderId(Long pizzaOrderId);

}
