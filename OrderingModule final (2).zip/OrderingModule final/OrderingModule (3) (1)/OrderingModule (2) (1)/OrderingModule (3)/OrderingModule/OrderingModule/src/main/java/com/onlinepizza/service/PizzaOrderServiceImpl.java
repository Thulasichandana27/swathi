package com.onlinepizza.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.onlinepizza.model.PizzaOrder;
import com.onlinepizza.model.OrderLine;
import com.onlinepizza.repository.IPizzaOrderRepository;
import com.onlinepizza.repository.IOrderLineRepository;

import java.util.ArrayList;

@Service
public class PizzaOrderServiceImpl {

	@Autowired
	private IPizzaOrderRepository pizzaOrderRepository;

	@Autowired
	private IOrderLineRepository orderLineRepository;

	// Save Pizza Order and Order Lines
	public PizzaOrder savePizzaOrder(PizzaOrder pizzaOrder) {
		// Ensure that the orderLines list is not null
		if (pizzaOrder.getOrderLines() == null) {
			pizzaOrder.setOrderLines(new ArrayList<>());
		}

		// Save the PizzaOrder first (so we get the ID)
		pizzaOrder = pizzaOrderRepository.save(pizzaOrder);

		// Now, save each OrderLine associated with this PizzaOrder
		for (OrderLine orderLine : pizzaOrder.getOrderLines()) {
			// Set the PizzaOrder in each OrderLine before saving
			orderLine.setPizzaOrder(pizzaOrder);
			orderLineRepository.save(orderLine);  // Save the OrderLine
		}

		return pizzaOrder;
	}

	// Add functionality to create OrderLine separately if needed
	public OrderLine createOrderLine(Long pizzaOrderId, Integer quantity) {
		PizzaOrder pizzaOrder = pizzaOrderRepository.findById(pizzaOrderId)
				.orElseThrow(() -> new RuntimeException("PizzaOrder not found"));

		OrderLine orderLine = new OrderLine();
		orderLine.setQuantity(quantity);
		orderLine.setPizzaOrder(pizzaOrder);  // Associate with the existing PizzaOrder

		// Save the OrderLine
		return orderLineRepository.save(orderLine);
	}
}
