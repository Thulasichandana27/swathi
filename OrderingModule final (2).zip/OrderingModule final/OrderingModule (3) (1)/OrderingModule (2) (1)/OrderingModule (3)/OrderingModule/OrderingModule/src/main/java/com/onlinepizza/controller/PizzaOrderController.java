package com.onlinepizza.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.onlinepizza.model.PizzaOrder;
import com.onlinepizza.model.OrderLine;
import com.onlinepizza.service.PizzaOrderServiceImpl;

@RestController
@RequestMapping("/api/pizza-orders")
public class PizzaOrderController {

    @Autowired
    private PizzaOrderServiceImpl pizzaOrderService;

    // Create Pizza Order and Order Lines
    @PostMapping
    public ResponseEntity<PizzaOrder> createPizzaOrder(@RequestBody PizzaOrder pizzaOrder) {
        try {
            PizzaOrder createdOrder = pizzaOrderService.savePizzaOrder(pizzaOrder);
            return new ResponseEntity<>(createdOrder, HttpStatus.CREATED); // 201 Created
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST); // 400 Bad Request in case of errors
        }
    }

    // Create Order Line (separate)
    @PostMapping("/{pizzaOrderId}/order-lines")
    public ResponseEntity<OrderLine> createOrderLine(@PathVariable Long pizzaOrderId, @RequestBody Integer quantity) {
        try {
            OrderLine orderLine = pizzaOrderService.createOrderLine(pizzaOrderId, quantity);
            if (orderLine == null) {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND); // 404 Not Found if pizzaOrderId doesn't exist
            }
            return new ResponseEntity<>(orderLine, HttpStatus.CREATED); // 201 Created
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST); // 400 Bad Request in case of errors
        }
    }
}
