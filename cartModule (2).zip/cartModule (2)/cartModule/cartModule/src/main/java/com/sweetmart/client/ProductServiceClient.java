package com.sweetmart.client;

import com.sweetmart.dto.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "product-service")
public interface ProductServiceClient {
    @GetMapping("/products/get_product/{id}")
    Product getProductById(@PathVariable("id") int productId);
}
