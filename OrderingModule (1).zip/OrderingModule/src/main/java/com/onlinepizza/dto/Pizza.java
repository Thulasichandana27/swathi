package com.onlinepizza.dto;

public class Pizza {   

    private Integer pizzaId;    
    private String pizzaType;       
    private String pizzaName;      
    private String pizzaDescription;     
    private double pizzaCost;     
    private double pizzaCostAfterCoupon;  // Corrected the spelling from 'Coupan' to 'Coupon'

    // Getters and Setters
    public Integer getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(Integer pizzaId) {
        this.pizzaId = pizzaId;
    }

    public String getPizzaType() {
        return pizzaType;
    }

    public void setPizzaType(String pizzaType) {
        this.pizzaType = pizzaType;
    }

    public String getPizzaName() {
        return pizzaName;
    }

    public void setPizzaName(String pizzaName) {
        this.pizzaName = pizzaName;
    }

    public String getPizzaDescription() {
        return pizzaDescription;
    }

    public void setPizzaDescription(String pizzaDescription) {
        this.pizzaDescription = pizzaDescription;
    }

    public double getPizzaCost() {
        return pizzaCost;
    }

    public void setPizzaCost(double pizzaCost) {
        this.pizzaCost = pizzaCost;
    }

    public double getPizzaCostAfterCoupon() {
        return pizzaCostAfterCoupon;
    }

    public void setPizzaCostAfterCoupon(double pizzaCostAfterCoupon) {
        this.pizzaCostAfterCoupon = pizzaCostAfterCoupon;
    }
}