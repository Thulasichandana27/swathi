package com.onlinepizza.dto;

import java.time.LocalDate;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
//import com.onlinepizza.model.PizzaSize;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import com.onlinepizza.model.PizzaOrder;

@AllArgsConstructor
@NoArgsConstructor
public class PizzaOrderDTO {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingOrderId;

	@NotNull(message = "{pizzaId.notnull}")
	@Positive(message = "{pizzaId.positive}")
	private Integer pizzaId;

//	@NotNull(message = "{userName.notnull}")
//	private String userName;
//	
//	@NotNull(message = "{userId.notnull}")
//	private Integer userId;
	
	private double pizzaCost;
	private LocalDate dateOfOrder;

	@NotNull(message = "{quantity.notnull}")
	@Positive(message = "{quantity.positive}")
	@Range(min=1,max=200)
	private Integer quantity;

	

	private Double totalCost;

	// Getters and Setters
	public int getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(int bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public Integer getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(Integer pizzaId) {
		this.pizzaId = pizzaId;
	}

	public LocalDate getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(LocalDate dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	
//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//	
//	public Integer getUserId() {
//		return userId;
//	}
//	
//	public void setUserId(Integer userId) {
//		this.userId=userId;
//	}
	
//	public PizzaOrderDTO(PizzaOrder order) {
//	    this.bookingOrderId = order.getBookingOrderId();
//	    this.pizzaId = order.getPizzaId();
//	    this.userName = order.getUserName(); 
//	    this.userId=order.getUserId();// Ensure userName is present
//	    this.dateOfOrder = order.getDateOfOrder();
//	    this.quantity = order.getQuantity();
//	    this.totalCost = order.getTotalCost();
//	}


	

}
