package com.onlinepizza.model;

import java.time.LocalDate;

import com.onlinepizza.dto.Pizza;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pizza_orders")
public class PizzaOrder {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingOrderId;

    @Column(name = "pizza_id")
    private Integer pizzaId;
    
    @Column(name="pizza_cost")
    private double pizzaCost;
    
//    @Column(name = "user_id")
//    private Integer userId;
//    
//    @Column(name ="userName")
//    private String userName;

    @Column(nullable = false)
    private LocalDate dateOfOrder;

    @Column(nullable = false)
    private Integer quantity;

    private Double totalCost;


    
}