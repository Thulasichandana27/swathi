package com.onlinepizza.exception;


	public class InvalidSizeException extends Exception {
	    public InvalidSizeException(String message) {
	        super(message);
	    }
	}
