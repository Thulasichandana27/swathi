package com.onlinepizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlinepizza.model.PizzaOrder;

import java.util.List;
import java.util.Optional;

@Repository
public interface IPizzaOrderRepository extends JpaRepository<PizzaOrder,Integer> {


    PizzaOrder findByPizzaId(int pizzaId);
   
    Optional<PizzaOrder> findByBookingOrderId(Integer bookingOrderId);
    
	List<PizzaOrder> findByBookingOrderIdIn(List<Integer> bookingOrderIds);

//	List<PizzaOrder> findByUserName(String userName);

}
