package com.onlinepizza.client;


import com.onlinepizza.dto.Pizza;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(value="Pizza",url="http://localhost:5001/pizzas")
@Component
public interface PizzaServiceClient {

	
	  @GetMapping("/getPizzaId/{id}")
	    public ResponseEntity<Pizza> getPizzaId(@PathVariable("id") Integer pizzaId) ;
	       
	    
	    
	    @GetMapping ("/getPizzaCost/{id}")
	    public ResponseEntity<Double> getPizzaCost(@PathVariable("id") Integer pizzaId);
	
}

























//
//
//@GetMapping("/pizzas/view/{pizzaId}")
//Pizza viewPizza(@PathVariable(name="pizzaId") int pizzaId);
                                                   