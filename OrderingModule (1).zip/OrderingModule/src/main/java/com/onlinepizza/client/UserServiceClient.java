//package com.onlinepizza.client;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//
//import com.onlinepizza.dto.User;
////import com.onlinepizza.dto.UserDto;
////import com.onlinepizza.exceptions.UserNotFoundException;
//
//
//
//@FeignClient(value = "IUserService",url="http://localhost:5000/users")
//@Component
//public interface UserServiceClient {
//	
//	@GetMapping("/getName/{id}")
//	String getUserName(@PathVariable("id") Integer userId);
//   
//   @GetMapping("/getId/{id}")
//   User getUserId(@PathVariable("id") Integer userId);
//	 
//
//}

//
//
