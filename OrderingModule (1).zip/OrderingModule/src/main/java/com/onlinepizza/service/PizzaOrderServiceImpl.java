package com.onlinepizza.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.onlinepizza.client.PizzaServiceClient;
//import com.onlinepizza.client.UserServiceClient;

import com.onlinepizza.dto.Pizza;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.onlinepizza.dto.PizzaOrderDTO;
import com.onlinepizza.dto.User;
import com.onlinepizza.exception.OrderIdNotFoundException;
import com.onlinepizza.exception.OrderNotFoundException;
import com.onlinepizza.exception.UserNotFoundException;
import com.onlinepizza.model.PizzaOrder;
import com.onlinepizza.repository.IPizzaOrderRepository;

import jakarta.validation.Valid;

@Service
public class PizzaOrderServiceImpl implements IPizzaOrderService {

	@Autowired
	private IPizzaOrderRepository pizzaOrderRepository;

	@Autowired
	private PizzaServiceClient pizzaServiceClient;



	 public PizzaOrderDTO bookPizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO) {
		pizzaOrderDTO.setDateOfOrder(LocalDate.now());
		
		Double totalCost = calculateTotalCost(pizzaOrderDTO.getPizzaId(), pizzaOrderDTO.getQuantity());
        pizzaOrderDTO.setTotalCost(totalCost);

        // Additional logic to save the pizza order
        PizzaOrder pizzaOrder = convertToEntity(pizzaOrderDTO);
        pizzaOrderRepository.save(pizzaOrder);

        return convertToDTO(pizzaOrder);
    }

    private Double calculateTotalCost(Integer pizzaId, int quantity) {
        double totalCost = 0;

        // Fetch pizza details
        ResponseEntity<Pizza> pizzaResponse = pizzaServiceClient.getPizzaId(pizzaId);
        ResponseEntity<Double> pizzaCostResponse = pizzaServiceClient.getPizzaCost(pizzaId);

        if (pizzaResponse.getStatusCode() != HttpStatus.OK || pizzaCostResponse.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException("Failed to fetch pizza details or cost");
        }

        Pizza pizza = pizzaResponse.getBody();
        Double pizzaCost = pizzaCostResponse.getBody();

        if (pizza == null || pizzaCost == null) {
            throw new RuntimeException("Pizza not found with ID: " + pizzaId);
        }

        // Calculate total cost
        totalCost += pizzaCost * quantity;

        return totalCost;
    }

   
   
   

	@Override
	public PizzaOrderDTO updatePizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO) {
		PizzaOrder existingOrder = pizzaOrderRepository.findById(pizzaOrderDTO.getBookingOrderId())
				.orElseThrow(() -> new RuntimeException("Pizza order not found with ID: " + pizzaOrderDTO.getBookingOrderId()));

		// Update the existing order using DTO values
		PizzaOrder updatedOrder = convertToEntity(pizzaOrderDTO);
		updatedOrder.setTotalCost(calculateTotalCost(updatedOrder.getPizzaId(), updatedOrder.getQuantity()));
		updatedOrder.setBookingOrderId(existingOrder.getBookingOrderId()); // Preserve ID

		// Save the updated order and return as DTO
		return convertToDTO(pizzaOrderRepository.save(updatedOrder));

	}

	@Override
	public PizzaOrderDTO cancelPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException {
		PizzaOrder existingOrder = pizzaOrderRepository.findById(bookingOrderId)
				.orElseThrow(() -> new OrderIdNotFoundException("No pizza order found with Booking Order ID: " + bookingOrderId));

		// Convert entity to DTO before deletion
		PizzaOrderDTO deletedOrderDTO = convertToDTO(existingOrder);

		// Delete the order from the database
		pizzaOrderRepository.deleteById(bookingOrderId);

		System.out.println("Order ID " + bookingOrderId + " deleted successfully.");

		// Return details of the deleted order
		return deletedOrderDTO;
	}

	@Override
	public PizzaOrderDTO viewPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException {
		// Fetch the pizza order using orderId (as a reference, not primary key)
		PizzaOrder existingOrder = pizzaOrderRepository.findById(bookingOrderId)
				.orElseThrow(() -> new OrderIdNotFoundException("No pizza order found with Booking Order ID: " + bookingOrderId));

		// Convert entity to DTO and return
		return convertToDTO(existingOrder);
	}

//	public Double calculateTotalCost(Integer pizzaId, int quantity) {
//		double totalCost = 0;
//			Pizza pizza = pizzaServiceClient.getPizzaId(pizzaId);
//			totalCost += pizzaServiceClient.getPizzaCost(pizzaId) * quantity;
//		return totalCost;
//	}

	private PizzaOrder convertToEntity(PizzaOrderDTO pizzaOrderDTO) {
	    PizzaOrder pizzaOrder = new PizzaOrder();
	    pizzaOrder.setBookingOrderId(pizzaOrderDTO.getBookingOrderId());
	    pizzaOrder.setPizzaId(pizzaOrderDTO.getPizzaId());
	   // pizzaOrder.setUserName(pizzaOrderDTO.getUserName());  // Added
	    pizzaOrder.setDateOfOrder(pizzaOrderDTO.getDateOfOrder());
	    pizzaOrder.setQuantity(pizzaOrderDTO.getQuantity());
	    pizzaOrder.setTotalCost(pizzaOrderDTO.getTotalCost());
	    return pizzaOrder;
	}
	

	private PizzaOrderDTO convertToDTO(PizzaOrder pizzaOrder) {
	    PizzaOrderDTO pizzaOrderDTO = new PizzaOrderDTO();
	    pizzaOrderDTO.setBookingOrderId(pizzaOrder.getBookingOrderId());
	    pizzaOrderDTO.setPizzaId(pizzaOrder.getPizzaId());
	   // pizzaOrderDTO.setUserName(pizzaOrder.getUserName());  // Added
	    pizzaOrderDTO.setDateOfOrder(pizzaOrder.getDateOfOrder());
	    pizzaOrderDTO.setQuantity(pizzaOrder.getQuantity());
	    pizzaOrderDTO.setTotalCost(pizzaOrder.getTotalCost());
	    return pizzaOrderDTO;
	}

	
	@Override
    public List<PizzaOrderDTO> viewAllPizzaOrders() {
        List<PizzaOrder> pizzaOrders = pizzaOrderRepository.findAll();
        List<PizzaOrderDTO> pizzaOrderDTOs = new ArrayList<>();
        
        for (PizzaOrder order : pizzaOrders) {
            PizzaOrderDTO orderDTO = new PizzaOrderDTO();
            orderDTO.setBookingOrderId(order.getBookingOrderId());
            orderDTO.setPizzaId(order.getPizzaId());
            orderDTO.setDateOfOrder(order.getDateOfOrder());
            orderDTO.setQuantity(order.getQuantity());
            orderDTO.setTotalCost(order.getTotalCost());

            pizzaOrderDTOs.add(orderDTO);
        }
	
        
        return pizzaOrderDTOs;
    }

	
//	@Override
//    public List<PizzaOrderDTO> GetAllByUserName(Integer userId) {
//        // Get userName using Feign Client by userId
//        String userName = userServiceClient.getUserName(userId);
//        if (userName == null || userName.isEmpty()) {
//            throw new UserNotFoundException("User not found with ID: " + userId);
//        }
//
//        // Fetch orders from the database using userName
//        List<PizzaOrder> orders = pizzaOrderRepository.findByUserName(userName);
//        if (orders.isEmpty()) {
//            throw new OrderNotFoundException("No orders found for user with ID: " + userId);
//        }
//
//        // Convert PizzaOrder to PizzaOrderDTO
//        List<PizzaOrderDTO> orderDTOs = new ArrayList<>();
//        for (PizzaOrder order : orders) {
//            orderDTOs.add(convertToDTO(order));
//        }
//        return orderDTOs;
//    }
	}

   
	