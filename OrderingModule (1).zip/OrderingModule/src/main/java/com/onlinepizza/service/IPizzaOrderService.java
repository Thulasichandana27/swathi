package com.onlinepizza.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


import com.onlinepizza.dto.PizzaOrderDTO;
import com.onlinepizza.dto.User;
import com.onlinepizza.exception.InvalidSizeException;
import com.onlinepizza.exception.OrderIdNotFoundException;
import com.onlinepizza.model.PizzaOrder;

import jakarta.validation.Valid;

@Service
public interface IPizzaOrderService {
	PizzaOrderDTO bookPizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO);

	PizzaOrderDTO updatePizzaOrder(@Valid PizzaOrderDTO pizzaOrderDTO);

	PizzaOrderDTO cancelPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException;

	PizzaOrderDTO viewPizzaOrder(int bookingOrderId) throws OrderIdNotFoundException;
	 List<PizzaOrderDTO> viewAllPizzaOrders();

	
//	 List<PizzaOrderDTO> GetAllByUserName(Integer userId);
	 

}


/*

{
	  "dateOfOrder": "2025-03-06",
	  "quantity": 2,
	  "size": "Large",
	  "totalCost": 25.00,
	  "pizza": {
	    "pizzaType": "Pepperoni",
	    "pizzaName": "Pepperoni Pizza",
	    "pizzaDescription": "A delicious pizza topped with pepperoni and mozzarella.",
	    "pizzaCost": 12.99,
	    "pizzaCostAfterCoupan": 10.39
	  },
	  "order": {
	    "orderType": "Delivery",
	    "orderDescription": "Large pepperoni pizza with extra cheese",
	    "customerId": 2001
	  },
	  "coupon": {
	    "code": "PIZZA20",
	    "type": "Percentage",
	    "discount": 20.0,
	    "expiryDate": "2025-12-31"
	  }
	}*/