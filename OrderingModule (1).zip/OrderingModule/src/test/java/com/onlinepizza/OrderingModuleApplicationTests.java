package com.onlinepizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderingModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
