package com.onlinepizza.security;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.onlinepizza.model.User;
import com.onlinepizza.repository.IUserRepository;

@Component
@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private IUserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

        Optional<User> opt=userRepository.findByUserName(userName);
        if(opt.isEmpty()){
            throw new UsernameNotFoundException("User Not Found");
        }
        User user=opt.get();
        org.springframework.security.core.userdetails.User u=new
                org.springframework.security.core.userdetails.User(user.getUserName(),user.getPassword(),
                user.getRoles().stream().map( r->new SimpleGrantedAuthority(r.toString())).collect(Collectors.toSet()));
        return u;
    }
}