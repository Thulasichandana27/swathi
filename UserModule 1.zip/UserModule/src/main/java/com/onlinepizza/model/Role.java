package com.onlinepizza.model;

public enum Role {
ADMIN,CUSTOMER
}
