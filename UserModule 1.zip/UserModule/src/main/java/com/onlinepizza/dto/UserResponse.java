package com.onlinepizza.dto;

public record UserResponse(String msg,String token) {
}