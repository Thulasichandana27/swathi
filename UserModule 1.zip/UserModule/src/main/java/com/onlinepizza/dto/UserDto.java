package com.onlinepizza.dto;

import java.util.Set;

import com.onlinepizza.model.Role;
import com.onlinepizza.model.User;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;


public class UserDto {
	
	private int userId;
	
	@NotNull(message = "{firstName.notnull}")
    @Size(min = 2, max = 50, message = "{firstName.size}")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "{firstName.pattern}")
    @Column(nullable = false)
    private String firstName;

    @NotNull(message = "{lastName.notnull}")
    @Size(min = 2, max = 50, message = "{lastName.size}")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "{lastName.pattern}")
    @Column(nullable = false)
    private String lastName;

    @NotNull(message = "{userName.required}")
    @Size(min = 3, max = 30, message = "{userName.size}")
    @Pattern(regexp = "^[a-zA-Z0-9_.]+$", message = "{userName.pattern}")
    @Column(nullable = false, unique = true)
    private String userName;

    @NotNull(message = "{email.required}")
    @Email(message = "{email.valid}")
    @Column(nullable = false, unique = true)
    private String email;

    @NotNull(message = "{password.required}")
    @Size(min = 8, message = "{password.size}")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", 
             message = "{password.pattern}")
    @Column(nullable = false)
    private String password;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "roletable", joinColumns = @JoinColumn(name = "userId"))
    @Enumerated(EnumType.STRING)
    @Column(name = "roles")
    @NotNull(message = "{roles.required}")
    private Set<Role> roles;


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Set<Role> getRoles() {
		return roles;
	}


	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	
	
}
