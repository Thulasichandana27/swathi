package com.onlinepizza.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlinepizza.model.User;

@Repository
public interface IUserRepository extends JpaRepository<User, Integer> {
    
	
	// Custom query methods can be added here if needed
    
    Optional<User> findByEmail(String email);
    Optional<User> findByUserNameAndPassword(String userName, String password);
    //selct *from user where username=?
    Optional<User> findByUserName(String userName);
    boolean existsByUserName(String userName);
    boolean existsByEmail(String email);
}


