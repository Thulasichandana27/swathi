package com.onlinepizza.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;


import com.onlinepizza.dto.UserDto;
import com.onlinepizza.dto.UserRequest;
import com.onlinepizza.dto.UserResponse;
import com.onlinepizza.exceptions.UserNotFoundException;
import com.onlinepizza.jwt.JwtService;
import com.onlinepizza.model.User;
import com.onlinepizza.service.IUserService;

import jakarta.validation.Valid;

import jakarta.validation.constraints.Min;

@RestController
@RequestMapping(value="/users")
public class UserController {

    @Autowired
    private IUserService userService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
   

   
	  @PostMapping(value="/register") 
	 public ResponseEntity<UserDto>
	 registerUser(@Valid @RequestBody UserDto userDto) {
	 userDto.setPassword(passwordEncoder.encode(userDto.getPassword())); UserDto
	 createdUser = userService.registerUser(userDto); return new
	 ResponseEntity<>(createdUser, HttpStatus.CREATED); }
	 
    
    
    @GetMapping
    public ResponseEntity<List<UserDto>> getAllUsers() {
        List<UserDto> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable int id) {
        Optional<UserDto> userDto = userService.getUserById(id);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}") 
    public ResponseEntity<Void> deleteUserById(@PathVariable int id) {
        userService.deleteUserById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable int id, @Valid @RequestBody UserDto updatedUserDto) {
        UserDto updatedUser = userService.updateUser(id, updatedUserDto);
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }


    @PostMapping(value = "/login")
    public ResponseEntity<UserResponse> login(@RequestBody UserRequest userRequest) {
        try {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                    userRequest.getUserName(), userRequest.getPassword()
            );
            var authentication = authenticationManager.authenticate(authenticationToken);
            if (authentication.isAuthenticated()) {
                // Generate Token
                var token = jwtService.generateToken(userRequest.getUserName());
                return new ResponseEntity<>(new UserResponse("Login Success", token), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new UserResponse("Login Failed", null), HttpStatus.UNAUTHORIZED);
            }
        } catch (BadCredentialsException ex) {
            return new ResponseEntity<>(new UserResponse("Invalid username or password", null), HttpStatus.UNAUTHORIZED);
        } catch (Exception ex) {
            return new ResponseEntity<>(new UserResponse("An unexpected error occurred: " + ex.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/username/{userName}")
    public ResponseEntity<UserDto> findByUserName(@PathVariable String userName) {
        Optional<UserDto> userDto = userService.findByUserName(userName);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> new UserNotFoundException("User not found with username: " + userName));
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
    
    
    @GetMapping("/getName/{id}")
	 public ResponseEntity<String> getUserName(@PathVariable("id") Integer userId){
    	String userName = userService.getUserName(userId);
        if (userName == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(userName, HttpStatus.OK);
    }

    
    @GetMapping("/getId/{id}")
    public ResponseEntity<User> getUserId(@PathVariable("id") Integer userId) {
        User user = userService.getUserId(userId);
        if (user == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    
    
}
	
