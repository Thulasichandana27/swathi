package com.onlinepizza.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;

import com.onlinepizza.dto.UserDto;
import com.onlinepizza.model.User;


public interface IUserService {

    // Register a new user
    UserDto registerUser(UserDto userDto);

    // Get all users
    List<UserDto> getAllUsers();

    // Get user by ID
    Optional<UserDto> getUserById(int userId);

    // Delete user by ID
    void deleteUserById(int userId);

    // Update user credentials
    UserDto updateUser(int userId, UserDto updatedUserDto);

    // User login
    Optional<UserDto> login(String userName, String password);

    // Find user by username
    Optional<UserDto> findByUserName(String userName);
    
    User getUserId(Integer userId);
    String getUserName(Integer userId);
    
    
    
    
    
    
    
    
    
    
    
    
   
    
}