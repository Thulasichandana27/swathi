package com.onlinepizza.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.onlinepizza.dto.UserDto;

import com.onlinepizza.exceptions.UserNotFoundException;
import com.onlinepizza.model.User;
import com.onlinepizza.repository.IUserRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.ConstraintViolationException;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

    @Autowired
    private IUserRepository userRepository;

 
    public UserDto registerUser(UserDto userDto) {
        // Check if the username already exists
        if (userRepository.existsByUserName(userDto.getUserName())) {
            throw new RuntimeException("Username already exists");
        }
        // Check if the email already exists
        if (userRepository.existsByEmail(userDto.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        // Convert DTO to Entity
        User user = convertToEntity(userDto);
        
        try {
            // Save the user entity to the database
            user = userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            if (e.getCause() instanceof ConstraintViolationException) {
                throw new IllegalArgumentException("Username or Email is already taken");
            }
            throw e;
        }
        
        // Convert Entity to DTO and return
        return convertToDto(user);
    }
  
    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<UserDto> getUserById(int userId) {
        return userRepository.findById(userId)
                .map(this::convertToDto);
    }

    @Override
    public void deleteUserById(int userId) {
        userRepository.deleteById(userId);
    }

    @Override
    public UserDto updateUser(int userId, UserDto updatedUserDto) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setFirstName(updatedUserDto.getFirstName());
            user.setLastName(updatedUserDto.getLastName());
            user.setUserName(updatedUserDto.getUserName());
            user.setEmail(updatedUserDto.getEmail());
            user.setPassword(updatedUserDto.getPassword());
            user.setRoles(updatedUserDto.getRoles());
            user = userRepository.save(user);
            return convertToDto(user);
        } else {
            throw new UserNotFoundException("User not found with ID: " + userId);
        }
    }

    @Override
    public Optional<UserDto> login(String userName, String password) {
        Optional<User> optionalUser = userRepository.findByUserNameAndPassword(userName, password);
        return optionalUser.map(this::convertToDto);
    }

    @Override
    public Optional<UserDto> findByUserName(String userName) {
        return userRepository.findByUserName(userName)
                .map(this::convertToDto);
    }

    private UserDto convertToDto(User user) {
        UserDto userDto = new UserDto();
        userDto.setUserId(user.getUserId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setUserName(user.getUserName());
        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setRoles(user.getRoles());
        return userDto;
    }

    
    private User convertToEntity(UserDto userDto) {
        User user = new User();
        user.setUserId(userDto.getUserId());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setUserName(userDto.getUserName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setRoles(userDto.getRoles());
        return user;
    }
    
    
    @Override
    public User getUserId(Integer userId) {
        return userRepository.findById(userId).orElse(null);
    }
    
    @Override
    public String getUserName(Integer userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getUserName() : null;
    }

   

	
  
}